import express, { Request, Response } from "express";
import path from "path";
import dns from "dns";
import { createServer as createViteServer } from "vite";

// Set localhost DNS resolution to IPv4 first
dns.setDefaultResultOrder("ipv4first");

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database State for Full Interaction
interface User {
  id: number;
  username: string;
  email: string;
  role: "admin" | "instructor" | "client";
  fullName: string;
}

interface Client {
  id: number;
  userId: number;
  dateOfBirth: string; // YYYY-MM-DD
  phone: string; // +375 (29) XXX-XX-XX
  address: string;
  registrationDate: string;
  clubCardId: number | null;
}

interface Instructor {
  id: number;
  userId: number;
  specializationIds: number[];
  experienceYears: number;
  photoUrl: string;
  hireDate: string;
}

interface Equipment {
  id: number;
  name: string;
  type: "cardio" | "strength" | "functional";
  lastMaintenanceDate: string;
}

interface GymHall {
  id: number;
  name: string;
  capacity: number;
  equipments: { equipmentId: number; quantity: number }[];
}

interface WorkoutType {
  id: number;
  name: string;
  description: string;
  pricePerSession: number;
  pricePerCycle: number;
  category: "group" | "individual";
}

interface Group {
  id: number;
  name: string;
  workoutTypeId: number;
  instructors: { instructorId: number; role: "main" | "assistant" }[];
  clientIds: number[];
}

interface ScheduledClass {
  id: number;
  groupId: number;
  startTime: string; // ISO String
  endTime: string; // ISO String
  hallId: number;
  instructorIds: number[];
}

interface GroupEnrollment {
  id: number;
  clientId: number;
  groupId: number;
  enrollmentDate: string;
  paidAmount: number;
  paymentStatus: "paid" | "pending";
}

interface IndividualSession {
  id: number;
  clientId: number;
  instructorId: number;
  workoutTypeId: number;
  datetime: string; // ISO String
  durationMinutes: number;
  price: number;
  status: "scheduled" | "completed" | "cancelled";
}

interface ClubCard {
  id: number;
  cardType: "monthly" | "yearly" | "trial";
  price: number;
  validFrom: string;
  validTo: string;
  clientId: number | null;
}

interface PromoCode {
  id: number;
  code: string;
  discountPercent: number;
  validFrom: string;
  validTo: string;
  isActive: boolean;
  applicableTo: "group" | "individual" | "club_card" | "all";
}

interface PromoCodeUsage {
  id: number;
  promoCodeId: number;
  clientId: number;
  usedAt: string;
  discountApplied: number;
}

interface NewsItem {
  id: number;
  title: string;
  slug: string;
  summary: string;
  fullText: string;
  imageUrl: string;
  publishedDate: string;
  authorId: number;
}

interface Review {
  id: number;
  clientId: number;
  rating: number; // 1-5
  text: string;
  createdAt: string;
}

interface Vacancy {
  id: number;
  position: string;
  description: string;
  salary?: string;
  isActive: boolean;
}

interface FAQItem {
  id: number;
  question: string;
  answer: string;
  addedDate: string;
}

interface ContactPerson {
  id: number;
  fullName: string;
  role: string;
  phone: string;
  email: string;
  imageUrl: string;
}

interface CompanyHistory {
  id: number;
  year: number;
  event: string;
}

// ------------------- POPULATION OF DATA -------------------
// Pre-filled data: 10 clients, 5 instructors, 6 workout types, 5 groups, 15 scheduled classes, 10 individual sessions, 5 news, 5 reviews, 3 promocodes

let users: User[] = [
  { id: 1, username: "admin", email: "admin@fitness.by", role: "admin", fullName: "Иван Иванов" },
  { id: 2, username: "trainer_pavel", email: "pavel@fitness.by", role: "instructor", fullName: "Павел Сидоров" },
  { id: 3, username: "trainer_olga", email: "olga@fitness.by", role: "instructor", fullName: "Ольга Козлова" },
  { id: 4, username: "trainer_dmitry", email: "dmitry@fitness.by", role: "instructor", fullName: "Дмитрий Новиков" },
  { id: 5, username: "trainer_elena", email: "elena@fitness.by", role: "instructor", fullName: "Елена Смирнова" },
  { id: 6, username: "trainer_artur", email: "artur@fitness.by", role: "instructor", fullName: "Артур Петров" },
  { id: 7, username: "alex123", email: "alex@mail.ru", role: "client", fullName: "Александр Петров" },
  { id: 8, username: "mary_k", email: "mary@yandex.ru", role: "client", fullName: "Мария Ковалева" },
  { id: 9, username: "den_by", email: "denis@tut.by", role: "client", fullName: "Денис Кравченко" },
  { id: 10, username: "kate_m", email: "kate@gmail.com", role: "client", fullName: "Екатерина Морозова" },
  { id: 11, username: "serg_f", email: "sergei@fitness.by", role: "client", fullName: "Сергей Федоров" },
  { id: 12, username: "vlad_gym", email: "vlad@mail.ru", role: "client", fullName: "Владислав Тарасов" },
  { id: 13, username: "anna_s", email: "anna@yandex.by", role: "client", fullName: "Анна Соколова" },
  { id: 14, username: "maxim_p", email: "maxim@tut.by", role: "client", fullName: "Максим Попов" },
  { id: 15, username: "julia_r", email: "julia@gmail.com", role: "client", fullName: "Юлия Рыбакова" },
  { id: 16, username: "artem_k", email: "artem@mail.ru", role: "client", fullName: "Артем Кузнецов" }
];

let clients: Client[] = [
  { id: 1, userId: 7, dateOfBirth: "1995-04-12", phone: "+375 (29) 111-22-33", address: "г. Минск, ул. Ленина, д. 5, кв. 12", registrationDate: "2026-01-10", clubCardId: 1 },
  { id: 2, userId: 8, dateOfBirth: "1998-09-18", phone: "+375 (29) 222-33-44", address: "г. Минск, пр. Независимости, д. 45, кв. 3", registrationDate: "2026-02-15", clubCardId: 2 },
  { id: 3, userId: 9, dateOfBirth: "1990-01-25", phone: "+375 (29) 333-44-55", address: "г. Минск, ул. Сурганова, д. 18, кв. 99", registrationDate: "2026-03-01", clubCardId: 3 },
  { id: 4, userId: 10, dateOfBirth: "2000-11-05", phone: "+375 (29) 444-55-66", address: "г. Минск, ул. Коласа, д. 12, кв. 4", registrationDate: "2026-03-10", clubCardId: null },
  { id: 5, userId: 11, dateOfBirth: "1988-08-30", phone: "+375 (29) 555-66-77", address: "г. Минск, ул. Некрасова, д. 22, кв. 14", registrationDate: "2026-03-12", clubCardId: 4 },
  { id: 6, userId: 12, dateOfBirth: "1993-02-14", phone: "+375 (29) 666-77-88", address: "г. Минск, ул. Гинтовта, д. 3, кв. 56", registrationDate: "2026-03-15", clubCardId: 5 },
  { id: 7, userId: 13, dateOfBirth: "2004-07-22", phone: "+375 (29) 777-88-99", address: "г. Минск, ул. Матусевича, д. 9, кв. 120", registrationDate: "2026-04-01", clubCardId: null },
  { id: 8, userId: 14, dateOfBirth: "1985-05-15", phone: "+375 (29) 888-99-00", address: "г. Минск, ул. Притыцкого, д. 34, кв. 11", registrationDate: "2026-04-10", clubCardId: 6 },
  { id: 9, userId: 15, dateOfBirth: "1992-12-01", phone: "+375 (29) 999-00-11", address: "г. Минск, ул. Филимонова, д. 14, кв. 5", registrationDate: "2026-04-12", clubCardId: null },
  { id: 10, userId: 16, dateOfBirth: "1997-06-25", phone: "+375 (29) 123-45-67", address: "г. Минск, ул. Есенина, д. 8, кв. 42", registrationDate: "2026-04-14", clubCardId: 7 }
];

let instructors: Instructor[] = [
  { id: 1, userId: 2, specializationIds: [1, 2, 6], experienceYears: 8, photoUrl: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&q=80&w=200", hireDate: "2020-03-15" },
  { id: 2, userId: 3, specializationIds: [3, 4, 6], experienceYears: 5, photoUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200", hireDate: "2021-08-10" },
  { id: 3, userId: 4, specializationIds: [1, 5, 6], experienceYears: 12, photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200", hireDate: "2018-02-01" },
  { id: 4, userId: 5, specializationIds: [3, 5], experienceYears: 6, photoUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200", hireDate: "2022-09-01" },
  { id: 5, userId: 6, specializationIds: [2, 4, 6], experienceYears: 4, photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200", hireDate: "2023-11-20" }
];

let equipments: Equipment[] = [
  { id: 1, name: "Беговая дорожка LifeFitness", type: "cardio", lastMaintenanceDate: "2026-04-10" },
  { id: 2, name: "Велотренажер TechnoGym", type: "cardio", lastMaintenanceDate: "2026-04-12" },
  { id: 3, name: "Жим ногами регулируемый", type: "strength", lastMaintenanceDate: "2026-03-15" },
  { id: 4, name: "Машина Смита", type: "strength", lastMaintenanceDate: "2026-02-28" },
  { id: 5, name: "Набор TRX лент", type: "functional", lastMaintenanceDate: "2026-05-01" },
  { id: 6, name: "Гири чугунные (8-32 кг)", type: "functional", lastMaintenanceDate: "2026-05-05" }
];

let gymHalls: GymHall[] = [
  { id: 1, name: "Кардио-зона и Силовой Зал 1", capacity: 30, equipments: [{ equipmentId: 1, quantity: 8 }, { equipmentId: 2, quantity: 5 }, { equipmentId: 3, quantity: 2 }, { equipmentId: 4, quantity: 2 }] },
  { id: 2, name: "Малый зал пилатеса и йоги", capacity: 15, equipments: [{ equipmentId: 5, quantity: 10 }] },
  { id: 3, name: "Зал функционального тренинга", capacity: 20, equipments: [{ equipmentId: 5, quantity: 15 }, { equipmentId: 6, quantity: 12 }] }
];

let workoutTypes: WorkoutType[] = [
  { id: 1, name: "Силовой Кроссфит", description: "Интенсивная тренировка с использованием гирь, штанги и функциональных упражнений", pricePerSession: 30, pricePerCycle: 220, category: "group" },
  { id: 2, name: "Йога Баланс", description: "Гармония духа и тела, асаны, дыхательная гимнастика, улучшение гибкости", pricePerSession: 25, pricePerCycle: 180, category: "group" },
  { id: 3, name: "Пилатес Реформ", description: "Укрепление мышечного корсета, улучшение осанки и гибкости суставов", pricePerSession: 28, pricePerCycle: 195, category: "group" },
  { id: 4, name: "Кардио Марафон", description: "Интервальная выносливость, сжигание жира на профессиональных тренажерах", pricePerSession: 20, pricePerCycle: 150, category: "group" },
  { id: 5, name: "Индивидуальная тренировка с Мастером", description: "Персональное ведение, учет всех особенностей вашего тела и программы питания", pricePerSession: 45, pricePerCycle: 0, category: "individual" },
  { id: 6, name: "Экспресс Фитнес-Кураторство", description: "Разовая индивидуальная тренировка + разбор техники выполнения сложных упражнений", pricePerSession: 50, pricePerCycle: 0, category: "individual" }
];

let groups: Group[] = [
  { id: 1, name: "Кроссфит Утро", workoutTypeId: 1, instructors: [{ instructorId: 1, role: "main" }, { instructorId: 3, role: "assistant" }], clientIds: [1, 2, 3] },
  { id: 2, name: "Йога Релакс Вечер", workoutTypeId: 2, instructors: [{ instructorId: 2, role: "main" }], clientIds: [4, 5] },
  { id: 3, name: "Пилатес Pro", workoutTypeId: 3, instructors: [{ instructorId: 4, role: "main" }], clientIds: [6, 8] },
  { id: 4, name: "Выносливость 360", workoutTypeId: 4, instructors: [{ instructorId: 5, role: "main" }], clientIds: [1, 9] },
  { id: 5, name: "Кроссфит Эксперт", workoutTypeId: 1, instructors: [{ instructorId: 3, role: "main" }], clientIds: [2, 10] }
];

let scheduledClasses: ScheduledClass[] = [
  { id: 1, groupId: 1, startTime: "2026-05-25T08:00:00Z", endTime: "2026-05-25T09:00:00Z", hallId: 3, instructorIds: [1, 3] },
  { id: 2, groupId: 1, startTime: "2026-05-27T08:00:00Z", endTime: "2026-05-27T09:00:00Z", hallId: 3, instructorIds: [1, 3] },
  { id: 3, groupId: 1, startTime: "2026-05-29T08:00:00Z", endTime: "2026-05-29T09:00:00Z", hallId: 3, instructorIds: [1, 3] },
  { id: 4, groupId: 2, startTime: "2026-05-25T18:30:00Z", endTime: "2026-05-25T19:45:00Z", hallId: 2, instructorIds: [2] },
  { id: 5, groupId: 2, startTime: "2026-05-28T18:30:00Z", endTime: "2026-05-28T19:45:00Z", hallId: 2, instructorIds: [2] },
  { id: 6, groupId: 3, startTime: "2026-05-26T19:00:00Z", endTime: "2026-05-26T20:15:00Z", hallId: 2, instructorIds: [4] },
  { id: 7, groupId: 3, startTime: "2026-05-30T10:00:00Z", endTime: "2026-05-30T11:15:00Z", hallId: 2, instructorIds: [4] },
  { id: 8, groupId: 4, startTime: "2026-05-27T17:00:00Z", endTime: "2026-05-27T18:00:00Z", hallId: 1, instructorIds: [5] },
  { id: 9, groupId: 4, startTime: "2026-05-31T17:00:00Z", endTime: "2026-05-31T18:00:00Z", hallId: 1, instructorIds: [5] },
  { id: 10, groupId: 5, startTime: "2026-05-26T07:30:00Z", endTime: "2026-05-26T09:00:00Z", hallId: 3, instructorIds: [3] },
  { id: 11, groupId: 5, startTime: "2026-05-28T07:30:00Z", endTime: "2026-05-28T09:00:00Z", hallId: 3, instructorIds: [3] },
  { id: 12, groupId: 1, startTime: "2026-05-22T08:00:00Z", endTime: "2026-05-22T09:00:00Z", hallId: 3, instructorIds: [1, 3] }, // Past class - active today
  { id: 13, groupId: 2, startTime: "2026-05-21T18:30:00Z", endTime: "2026-05-21T19:45:00Z", hallId: 2, instructorIds: [2] }, // Past class
  { id: 14, groupId: 3, startTime: "2026-05-20T19:00:00Z", endTime: "2026-05-20T20:15:00Z", hallId: 2, instructorIds: [4] }, // Past class
  { id: 15, groupId: 4, startTime: "2026-05-19T17:00:00Z", endTime: "2026-05-19T18:00:00Z", hallId: 1, instructorIds: [5] }  // Past class
];

let groupEnrollments: GroupEnrollment[] = [
  { id: 1, clientId: 1, groupId: 1, enrollmentDate: "2026-05-01", paidAmount: 220, paymentStatus: "paid" },
  { id: 2, clientId: 2, groupId: 1, enrollmentDate: "2026-05-02", paidAmount: 220, paymentStatus: "paid" },
  { id: 3, clientId: 3, groupId: 1, enrollmentDate: "2026-05-05", paidAmount: 220, paymentStatus: "paid" },
  { id: 4, clientId: 4, groupId: 2, enrollmentDate: "2026-05-10", paidAmount: 180, paymentStatus: "pending" },
  { id: 5, clientId: 5, groupId: 2, enrollmentDate: "2026-05-11", paidAmount: 180, paymentStatus: "paid" },
  { id: 6, clientId: 6, groupId: 3, enrollmentDate: "2026-05-12", paidAmount: 195, paymentStatus: "paid" },
  { id: 7, clientId: 8, groupId: 3, enrollmentDate: "2026-05-10", paidAmount: 195, paymentStatus: "paid" },
  { id: 8, clientId: 1, groupId: 4, enrollmentDate: "2026-05-14", paidAmount: 150, paymentStatus: "paid" },
  { id: 9, clientId: 9, groupId: 4, enrollmentDate: "2026-05-15", paidAmount: 150, paymentStatus: "pending" },
  { id: 10, clientId: 2, groupId: 5, enrollmentDate: "2026-05-11", paidAmount: 220, paymentStatus: "paid" },
  { id: 11, clientId: 10, groupId: 5, enrollmentDate: "2026-05-12", paidAmount: 220, paymentStatus: "paid" }
];

let individualSessions: IndividualSession[] = [
  { id: 1, clientId: 1, instructorId: 1, workoutTypeId: 5, datetime: "2026-05-24T10:00:00Z", durationMinutes: 60, price: 45, status: "scheduled" },
  { id: 2, clientId: 2, instructorId: 2, workoutTypeId: 5, datetime: "2026-05-24T12:00:00Z", durationMinutes: 60, price: 45, status: "scheduled" },
  { id: 3, clientId: 3, instructorId: 3, workoutTypeId: 6, datetime: "2026-05-25T14:00:00Z", durationMinutes: 60, price: 50, status: "scheduled" },
  { id: 4, clientId: 4, instructorId: 4, workoutTypeId: 5, datetime: "2026-05-26T15:00:00Z", durationMinutes: 60, price: 45, status: "scheduled" },
  { id: 5, clientId: 5, instructorId: 1, workoutTypeId: 5, datetime: "2026-05-20T10:00:00Z", durationMinutes: 60, price: 45, status: "completed" }, // Past completed
  { id: 6, clientId: 6, instructorId: 2, workoutTypeId: 6, datetime: "2026-05-19T11:00:00Z", durationMinutes: 60, price: 50, status: "completed" }, // Past completed
  { id: 7, clientId: 8, instructorId: 3, workoutTypeId: 5, datetime: "2026-05-18T16:00:00Z", durationMinutes: 60, price: 45, status: "completed" }, // Past completed
  { id: 8, clientId: 9, instructorId: 4, workoutTypeId: 5, datetime: "2026-05-17T09:00:00Z", durationMinutes: 60, price: 45, status: "completed" }, // Past completed
  { id: 9, clientId: 10, instructorId: 5, workoutTypeId: 6, datetime: "2026-05-28T10:00:00Z", durationMinutes: 60, price: 50, status: "scheduled" },
  { id: 10, clientId: 1, instructorId: 2, workoutTypeId: 5, datetime: "2026-05-29T11:00:00Z", durationMinutes: 60, price: 45, status: "scheduled" }
];

let clubCards: ClubCard[] = [
  { id: 1, cardType: "yearly", price: 600, validFrom: "2026-01-01", validTo: "2026-12-31", clientId: 1 },
  { id: 2, cardType: "monthly", price: 60, validFrom: "2026-05-01", validTo: "2026-05-31", clientId: 2 },
  { id: 3, cardType: "monthly", price: 60, validFrom: "2026-05-01", validTo: "2026-05-31", clientId: 3 },
  { id: 4, cardType: "yearly", price: 600, validFrom: "2026-01-15", validTo: "2027-01-14", clientId: 5 },
  { id: 5, cardType: "monthly", price: 60, validFrom: "2026-05-10", validTo: "2026-06-09", clientId: 6 },
  { id: 6, cardType: "monthly", price: 60, validFrom: "2026-05-05", validTo: "2026-06-04", clientId: 8 },
  { id: 7, cardType: "trial", price: 15, validFrom: "2026-05-13", validTo: "2026-05-20", clientId: 10 },
  { id: 8, cardType: "monthly", price: 65, validFrom: "2026-06-01", validTo: "2026-06-30", clientId: null }, // Unissued
  { id: 9, cardType: "yearly", price: 550, validFrom: "2026-06-01", validTo: "2027-05-31", clientId: null }  // Unissued
];

let promoCodes: PromoCode[] = [
  { id: 1, code: "SUMMER20", discountPercent: 20, validFrom: "2026-05-01T00:00:00Z", validTo: "2026-08-31T23:59:59Z", isActive: true, applicableTo: "all" },
  { id: 2, code: "FITGROUP", discountPercent: 15, validFrom: "2026-05-01T00:00:00Z", validTo: "2026-06-30T23:59:59Z", isActive: true, applicableTo: "group" },
  { id: 3, code: "INDIVIDUAL50", discountPercent: 50, validFrom: "2026-05-01T00:00:00Z", validTo: "2026-05-31T23:59:59Z", isActive: true, applicableTo: "individual" },
  { id: 4, code: "EXPIRED10", discountPercent: 10, validFrom: "2025-01-01T00:00:00Z", validTo: "2025-12-31T23:59:59Z", isActive: false, applicableTo: "all" }
];

let promoCodeUsages: PromoCodeUsage[] = [
  { id: 1, promoCodeId: 1, clientId: 1, usedAt: "2026-05-01T12:00:00Z", discountApplied: 44 }
];

let news: NewsItem[] = [
  {
    id: 1,
    title: "Большое открытие нового Кроссфит-зала",
    slug: "grand-crossfit-open",
    summary: "Мы рады объявить об открытии нашего профессионального зала Кроссфит с абсолютно новым оборудованием!",
    fullText: "В эту субботу фитнес-клуб открывает свои двери в новом расширенном формате. Мы укомплектовали зал шведскими стенками, инновационными беговыми дорожками LifeFitness, наборами TRX лент и чугунных гирь от 8 до 32 кг. Все тренировки в этот день будут бесплатными для зарегистрированных клиентов с активными клубными картами. Приходите со своими друзьями и испытайте наши программы!",
    imageUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=600",
    publishedDate: "2026-05-18T10:00:00Z",
    authorId: 1
  },
  {
    id: 2,
    title: "Переход на летнее расписание групповых занятий",
    slug: "summer-schedule",
    summary: "Вниманию клиентов! С 1 июня мы вводим новые утренние и вечерние группы для вашего удобства в жаркий период дня.",
    fullText: "Для того чтобы тренировки оставались комфортными, мы переносим утренний Кроссфит на 7:30 утра, а вечерние сессии пилатеса и йоги будут начинаться в 19:30 и 20:30. Изменения уже доступны в онлайн-календаре. Пожалуйста, проверьте время ваших забронированных сессий и откорректируйте личные планы при необходимости.",
    imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=600",
    publishedDate: "2026-05-20T14:30:00Z",
    authorId: 1
  },
  {
    id: 3,
    title: "Оздоровительная Йога-Сессия на открытом воздухе",
    slug: "yoga-outdoor",
    summary: "В это воскресенье проведем специальное занятие 'Йога Баланс' в парке Челюскинцев.",
    fullText: "Встречаемся у центрального входа в парк в 09:45. Тренер Ольга Козлова проведет незабываемый дыхательный цикл в тени деревьев. Форма одежды - спортивная, коврики предоставляются клубом для первых 15 записавшихся. Стоимость участия входит в годовые и месячные абонементы без дополнительной оплаты.",
    imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=600",
    publishedDate: "2026-05-21T09:00:00Z",
    authorId: 1
  },
  {
    id: 4,
    title: "Регулярное обслуживание тренажерного парка завершено",
    slug: "maintenance-done",
    summary: "Все силовые и кардио установки прошли ежегодную техническую экспертизу.",
    fullText: "Безопасность наших клиентов - наш главный приоритет. В период с 10 по 15 мая все беговые дорожки LifeFitness, велотренажеры TechnoGym, машины Смита и жимы ногами прошли смазку, замену изношенных кабелей и проверку электроники. Всё оборудование полностью исправно и готово к вашим рекордным нагрузкам!",
    imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=600",
    publishedDate: "2026-05-16T17:00:00Z",
    authorId: 1
  },
  {
    id: 5,
    title: "Новый тренер по силовой подготовке уже в команде!",
    slug: "new-coach-dmitry",
    summary: "Приветствуем Дмитрия Новикова — нашего нового сертифицированного инструктора по Кроссфиту и бодибилдингу.",
    fullText: "Дмитрий имеет 12-летний опыт тренерской деятельности, является победителем республиканских соревнований и специалистом по подготовке атлетов любого уровня сложности. С сегодняшнего дня вы можете записаться к нему на индивидуальные развивающие занятия по Кроссфиту и ОФП через Личный кабинет.",
    imageUrl: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&q=80&w=600",
    publishedDate: "2026-05-15T11:00:00Z",
    authorId: 1
  }
];

let reviews: Review[] = [
  { id: 1, clientId: 1, rating: 5, text: "Прекрасный клуб! Новый кроссфит зал просто огонь, много свободных весов и отличный тренер Павел. Рекомендую всем годовую карту!", createdAt: "2026-05-15T14:00:00Z" },
  { id: 2, clientId: 2, rating: 5, text: "Очень душевная атмосфера на вечерней йоге у Ольги. Помогает полностью расслабиться после тяжелого рабочего дня.", createdAt: "2026-05-16T18:30:00Z" },
  { id: 3, clientId: 3, rating: 4, text: "Зал хороший, но в пиковые часы с 18 до 20 бывает сложно найти свободную беговую дорожку. Техническое обслуживание супер, всё исправно.", createdAt: "2026-05-17T20:00:00Z" },
  { id: 4, clientId: 5, rating: 5, text: "Провожу индивидуальные тренировки с Дмитрием. За месяц скинул 4 кг и заметно прибавил в силовых показателях. Профессионал!", createdAt: "2026-05-19T10:00:00Z" },
  { id: 5, clientId: 6, rating: 5, text: "Пилатес с Еленой - это лучшее что случалось с моей спиной. Перестала болеть поясница уже после третьей регулярной тренировки.", createdAt: "2026-05-20T11:45:00Z" }
];

let vacancies: Vacancy[] = [
  { id: 1, position: "Инструктор по Пилатесу / Стретчингу", description: "Ищем энергичного человека с профильным образованием или сертификатами. Обязанности: ведение групповых и индивидуальных занятий. Опыт работы от 2 лет.", salary: "2000 - 2500 BYN", isActive: true },
  { id: 2, position: "Администратор Рецепции", description: "Встреча гостей клуба, консультация по услугам, продажа абонементов, ведение кассовой отчетности. График 2/2.", salary: "1100 - 1300 BYN", isActive: true },
  { id: 3, position: "Дежурный тренер тренажерного зала", description: "Контроль порядка в зале, проведение вводных инструктажей, страховка клиентов, персональные тренировки. Спортивное телосложение обязательное.", salary: "от 1500 BYN", isActive: true },
  { id: 4, position: "Врач-диетолог / Специалист по питанию", description: "Проведение биоимпедансного анализа тела, разработка планов питания, лекции для клиентов. Неполный рабочий день.", salary: "по договоренности", isActive: false }
];

let faqs: FAQItem[] = [
  { id: 1, question: "Как записаться на первое ознакомительное занятие?", answer: "Вы можете зарегистрировать профиль на сайте и активировать бесплатную Пробную карту (Trial) в личном кабинете, после чего записаться на любое групповое или индивидуальное занятие согласно расписанию.", addedDate: "2026-01-15" },
  { id: 2, question: "Нужна ли медицинская справка для посещения зала?", answer: "Специальная справка не требуется, но при наличии хронических заболеваний мы настоятельно рекомендуем проконсультироваться с лечащим врачом и поставить в известность вашего персонального инструктора перед началом упражнений.", addedDate: "2026-02-01" },
  { id: 3, question: "Можно ли заморозить клубную карту на время отпуска?", answer: "Да, для Годовых абонементов доступна бесплатная заморозка сроком до 30 календарных дней. Заморозку можно оформить через администратора клуба или в Личном кабинете.", addedDate: "2026-02-18" },
  { id: 4, question: "Входят ли полотенца в стоимость абонемента?", answer: "Полотенца предоставляются бесплатно всем владельцам Годовых карт. Владельцы Месячных карт могут арендовать полотенце на рецепции за символическую плату.", addedDate: "2026-03-05" },
  { id: 5, question: "Каковы условия отмены индивидуальной тренировки?", answer: "Вы можете отменить забронированную индивидуальную тренировку без каких-либо удержаний не позднее чем за 12 часов до её планового начала. При отмене позже этого срока тренировка считается проведенной и оплачивается полностью.", addedDate: "2026-03-20" }
];

let contacts: ContactPerson[] = [
  { id: 1, fullName: "Константин Романов", role: "Управляющий директор клуба", phone: "+375 (17) 220-40-50", email: "romanov@fitness.by", imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200" },
  { id: 2, fullName: "Анастасия Шевченко", role: "Старший администратор рецепции", phone: "+375 (29) 111-44-55", email: "shevchenko@fitness.by", imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200" },
  { id: 3, fullName: "Сергей Васильев", role: "Руководитель тренерского штаба", phone: "+375 (29) 555-00-11", email: "vasilyev@fitness.by", imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200" },
  { id: 4, fullName: "Ирина Мельникова", role: "Менеджер по работе с корпоративными клиентами", phone: "+375 (29) 888-77-22", email: "melnikova@fitness.by", imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200" }
];

let companyHistory: CompanyHistory[] = [
  { id: 1, year: 2021, event: "Основание фитнес-клуба. Создание первого малого зала йоги и пилатеса в Минске, найм первых 3 инструкторов." },
  { id: 2, year: 2022, event: "Расширение площади до 500 кв.м. Закупка первой партии профессиональных кардиотренажеров TechnoGym." },
  { id: 3, year: 2023, event: "Открытие полноценной зоны Кроссфита и функциональных тренировок, запуск личного кабинета для клиентов с онлайн расписанием." },
  { id: 4, year: 2024, event: "Награда 'Лучший локальный фитнес-клуб Минска'. Превышение отметки в 1000 постоянных активных клиентов." },
  { id: 5, year: 2025, event: "Капитальная реновация силового зала, внедрение интеллектуальных систем кондиционирования воздуха и запуск CRM статистики." }
];

// --- Currency Exchange Rate Cache Engine ---
let exchangeRatesCache: any = null;
let exchangeRatesLastFetched = 0;

async function getExchangeRates(): Promise<any> {
  const ONE_HOUR = 60 * 60 * 1000;
  const now = Date.now();
  if (exchangeRatesCache && (now - exchangeRatesLastFetched < ONE_HOUR)) {
    return exchangeRatesCache;
  }
  try {
    const fetch = (await import("node-fetch")).default;
    const res = await fetch("https://api.exchangerate-api.com/v4/latest/USD");
    const data = await res.json();
    exchangeRatesCache = data;
    exchangeRatesLastFetched = now;
    console.log("Exchange rates cache updated successfully.");
    return data;
  } catch (err) {
    console.warn("Failed to fetch current exchange rates, relying on fallback.", err);
    // Standard robust fallback rates for BYN base
    return {
      base: "USD",
      rates: {
        BYN: 3.25, // 1 USD = 3.25 BYN
        EUR: 0.92, // 1 USD = 0.92 EUR
        USD: 1.0
      }
    };
  }
}

// ------ API ENDPOINTS ------

// 1. Exchange rates API proxy (requires auth)
app.get("/api/exchange-rate", async (req: Request, res: Response) => {
  // Authentication check simulation (check headers, or standard simulation role)
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "Только для авторизованных пользователей" });
  }
  try {
    const data = await getExchangeRates();
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: "Ошибка получения курса валют" });
  }
});

// 2. Random Exercise / Motivation API (forces fallback on failure)
app.get("/api/motivation", async (req: Request, res: Response) => {
  const fallbackQuotes = [
    "Движение — это жизнь, а регулярный фитнес — это здоровая и красивая жизнь!",
    "Твое тело способно выдержать почти всё. Твоя главная задача — убедить в этом свой разум.",
    "Каждая тренировка — это еще одна ступенька к сильной и уверенной версии самого себя.",
    "Секрет того, как вырваться вперед, кроется в том, чтобы сделать первый шаг уже сегодня.",
    "Трудности, с которыми ты сталкиваешься сегодня, развивают силу, которая понадобится тебе завтра."
  ];

  try {
    const fetch = (await import("node-fetch")).default;
    // Call zenquotes API or failover
    const quotesRes = await fetch("https://zenquotes.io/api/random");
    if (quotesRes.ok) {
      const data: any = await quotesRes.json();
      if (Array.isArray(data) && data[0] && data[0].q) {
        return res.json({ quote: data[0].q, author: data[0].a || "ZenQuotes" });
      }
    }
    throw new Error("Invalid response from zenquotes service");
  } catch (error) {
    console.log("Motivational API failed or was rate-limited, triggering clean fallback description logo.");
    const randomIndex = Math.floor(Math.random() * fallbackQuotes.length);
    res.json({ quote: fallbackQuotes[randomIndex], author: "Фитнес Мотиватор" });
  }
});

// 3. User Authentication & Registration (includes 18+ age checks and phone validation)
app.post("/api/auth/login", (req: Request, res: Response) => {
  const { username, email } = req.body;
  if (!username) {
    return res.status(400).json({ error: "Необходимо указать имя пользователя" });
  }
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === username.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: "Пользователь не найден" });
  }
  
  // Find associated profile
  let clientProfile = clients.find(c => c.userId === user.id);
  let instructorProfile = instructors.find(i => i.userId === user.id);

  res.json({
    user,
    client: clientProfile,
    instructor: instructorProfile
  });
});

app.post("/api/auth/register", (req: Request, res: Response) => {
  const { username, email, fullName, dateOfBirth, phone, address } = req.body;
  
  if (!username || !email || !fullName || !dateOfBirth || !phone || !address) {
    return res.status(400).json({ error: "Пожалуйста, заполните все обязательные поля" });
  }

  // Validate age (>= 18 years old)
  const dob = new Date(dateOfBirth);
  const ageDiff = Date.now() - dob.getTime();
  const ageDate = new Date(ageDiff);
  const calculatedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
  
  if (calculatedAge < 18) {
    return res.status(400).json({ error: "Регистрация доступна только лицам старше 18 лет." });
  }

  // Validate phone format +375 (29) XXX-XX-XX / regex support
  const phonePattern = /^\+375\s?\((25|29|33|44)\)\s?[0-9]{3}-[0-9]{2}-[0-9]{2}$/;
  if (!phonePattern.test(phone)) {
    return res.status(400).json({ error: "Неверный формат телефона. Требуется: +375 (29) XXX-XX-XX" });
  }

  // Duplication check
  if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(400).json({ error: "Имя пользователя уже занято" });
  }

  // Create new user & client
  const newUserId = users.length + 1;
  const newClientId = clients.length + 1;

  const newUser: User = {
    id: newUserId,
    username,
    email,
    role: "client",
    fullName
  };

  const newClient: Client = {
    id: newClientId,
    userId: newUserId,
    dateOfBirth,
    phone,
    address,
    registrationDate: new Date().toISOString().split('T')[0],
    clubCardId: null
  };

  users.push(newUser);
  clients.push(newClient);

  console.log(`[LOG - INFO] Создан новый клиент: ID ${newClientId}, имя ${fullName}, телефон ${phone}`);

  res.status(201).json({
    user: newUser,
    client: newClient
  });
});

// Dynamic Content feeds
app.get("/api/news", (req: Request, res: Response) => {
  res.json(news);
});

app.get("/api/news/:slug", (req: Request, res: Response) => {
  const item = news.find(n => n.slug === req.params.slug);
  if (!item) return res.status(404).json({ error: "Новость не найдена" });
  res.json(item);
});

app.get("/api/vacancies", (req: Request, res: Response) => {
  res.json(vacancies.filter(v => v.isActive));
});

app.get("/api/faqs", (req: Request, res: Response) => {
  res.json(faqs);
});

app.get("/api/contacts", (req: Request, res: Response) => {
  res.json(contacts);
});

app.get("/api/about/history", (req: Request, res: Response) => {
  res.json(companyHistory.sort((a, b) => a.year - b.year));
});

app.get("/api/reviews", (req: Request, res: Response) => {
  // Map reviews with client names
  const responses = reviews.map(r => {
    const c = clients.find(cl => cl.id === r.clientId);
    const u = c ? users.find(usr => usr.id === c.userId) : null;
    return {
      ...r,
      clientName: u ? u.fullName : "Анонимный клиент"
    };
  });
  res.json(responses);
});

app.post("/api/reviews", (req: Request, res: Response) => {
  const { clientId, rating, text } = req.body;
  
  if (!clientId || !rating || !text) {
    return res.status(400).json({ error: "Не все поля отзыва переданы" });
  }

  // Double check that client exists and has had at least one workout session completed to give a review
  const clientExists = clients.some(c => c.id === clientId);
  if (!clientExists) {
    return res.status(400).json({ error: "Клиент не существует" });
  }

  // Create new review
  const newReview: Review = {
    id: reviews.length + 1,
    clientId,
    rating: parseInt(rating),
    text,
    createdAt: new Date().toISOString()
  };

  reviews.unshift(newReview);
  console.log(`[LOG - INFO] Оставлен отзыв от клиента: ID ${clientId}, оценка ${rating}`);
  res.status(201).json(newReview);
});

// Gym settings
app.get("/api/workout-types", (req: Request, res: Response) => {
  res.json(workoutTypes);
});

app.get("/api/groups", (req: Request, res: Response) => {
  // Enrich groups with workouts and instructors
  const enriched = groups.map(g => {
    const wt = workoutTypes.find(w => w.id === g.workoutTypeId);
    const insts = g.instructors.map(gi => {
      const instructor = instructors.find(i => i.id === gi.instructorId);
      const u = instructor ? users.find(usr => usr.id === instructor.userId) : null;
      return {
        instructorId: gi.instructorId,
        role: gi.role,
        fullName: u ? u.fullName : "Инструктор"
      };
    });
    return {
      ...g,
      workoutType: wt,
      instructorsEnriched: insts
    };
  });
  res.json(enriched);
});

app.get("/api/schedule", (req: Request, res: Response) => {
  const enriched = scheduledClasses.map(sc => {
    const grp = groups.find(g => g.id === sc.groupId);
    const wt = grp ? workoutTypes.find(w => w.id === grp.workoutTypeId) : null;
    const room = gymHalls.find(h => h.id === sc.hallId);
    const insts = sc.instructorIds.map(id => {
      const inst = instructors.find(i => i.id === id);
      const usr = inst ? users.find(u => u.id === inst.userId) : null;
      return usr ? usr.fullName : "Инструктор";
    });
    return {
      ...sc,
      groupName: grp ? grp.name : "Группа",
      workoutTypeName: wt ? wt.name : "Занятие",
      pricePerCycle: wt ? wt.pricePerCycle : 0,
      hallName: room ? room.name : "Основной зал",
      instructorNames: insts
    };
  });
  res.json(enriched);
});

app.get("/api/promocodes", (req: Request, res: Response) => {
  res.json(promoCodes.filter(p => p.isActive));
});

// Apply promo code logic
app.post("/api/promocodes/apply", (req: Request, res: Response) => {
  const { code, type, clientId } = req.body; // type: group, individual, club_card
  if (!code) {
    return res.status(400).json({ error: "Введите промокод" });
  }

  const promo = promoCodes.find(p => p.code.toUpperCase() === code.toUpperCase());
  if (!promo) {
    return res.status(404).json({ error: "Промокод не найден" });
  }

  if (!promo.isActive) {
    return res.status(400).json({ error: "Этот промокод деактивирован" });
  }

  const now = new Date();
  const validFrom = new Date(promo.validFrom);
  const validTo = new Date(promo.validTo);

  if (now < validFrom || now > validTo) {
    return res.status(400).json({ error: "Срок действия промокода еще не начался или уже истек" });
  }

  if (promo.applicableTo !== "all" && promo.applicableTo !== type) {
    return res.status(400).json({ error: `Этот промокод неприменим для категории услуги: ${type}` });
  }

  // Return discount info
  res.json({
    id: promo.id,
    code: promo.code,
    discountPercent: promo.discountPercent,
    applicableTo: promo.applicableTo
  });
});

// Purchase Club card
app.post("/api/club-cards/purchase", (req: Request, res: Response) => {
  const { clientId, cardType, price, discountPercent } = req.body;
  if (!clientId || !cardType || !price) {
    return res.status(400).json({ error: "Недостаточно данных для покупки абонемента" });
  }

  const client = clients.find(c => c.id === clientId);
  if (!client) {
    return res.status(404).json({ error: "Клиент не найден" });
  }

  const appliedDiscount = discountPercent || 0;
  const finalPrice = Math.round(price * (1 - appliedDiscount / 100));

  // Create card
  const newCardId = clubCards.length + 1;
  const validFrom = new Date();
  const validTo = new Date();
  if (cardType === "trial") {
    validTo.setDate(validTo.getDate() + 7);
  } else if (cardType === "monthly") {
    validTo.setMonth(validTo.getMonth() + 1);
  } else {
    validTo.setFullYear(validTo.getFullYear() + 1);
  }

  const card: ClubCard = {
    id: newCardId,
    cardType,
    price: finalPrice,
    validFrom: validFrom.toISOString().split('T')[0],
    validTo: validTo.toISOString().split('T')[0],
    clientId: clientId
  };

  clubCards.push(card);
  client.clubCardId = newCardId;

  console.log(`[LOG - INFO] Покупка абонемента: Клиент ID ${clientId}, тип "${cardType}", финальная цена ${finalPrice} BYN`);

  res.json({
    message: "Абонемент успешно приобретен",
    card,
    client
  });
});

// Group enrollment (with active card or custom cycle payment validation)
app.post("/api/groups/enroll", (req: Request, res: Response) => {
  const { clientId, groupId, discountPercent } = req.body;
  if (!clientId || !groupId) {
    return res.status(400).json({ error: "Отсутствует ID группы или клиента" });
  }

  const client = clients.find(c => c.id === clientId);
  if (!client) return res.status(404).json({ error: "Клиент не найден" });

  const grp = groups.find(g => g.id === groupId);
  if (!grp) return res.status(404).json({ error: "Группа не найдена" });

  if (grp.clientIds.includes(clientId)) {
    return res.status(400).json({ error: "Вы уже записаны в эту спортивную группу" });
  }

  const wt = workoutTypes.find(w => w.id === grp.workoutTypeId);
  if (!wt) return res.status(404).json({ error: "Вид тренировок не найден" });

  // Schedule overlap check
  const newEnrollmentClasses = scheduledClasses.filter(c => c.groupId === groupId);
  const clientEnrolledGrps = groups.filter(g => g.clientIds.includes(clientId));
  const clientClasses = scheduledClasses.filter(c => clientEnrolledGrps.some(eg => eg.id === c.groupId));

  for (const newCl of newEnrollmentClasses) {
    const newStart = new Date(newCl.startTime).getTime();
    const newEnd = new Date(newCl.endTime).getTime();
    
    for (const clCl of clientClasses) {
      const existingStart = new Date(clCl.startTime).getTime();
      const existingEnd = new Date(clCl.endTime).getTime();
      
      // Overlap calculation
      if (newStart < existingEnd && newEnd > existingStart) {
        return res.status(400).json({ 
          error: `У вас уже есть другое групповое занятие, которое пересекается с этой группой по времени!`
        });
      }
    }
  }

  // Calculate price with possible promo code
  const disc = discountPercent || 0;
  const finalPrice = Math.round(wt.pricePerCycle * (1 - disc / 100));

  // Register enrollment
  const newEnrollId = groupEnrollments.length + 1;
  const newEnrollment: GroupEnrollment = {
    id: newEnrollId,
    clientId,
    groupId,
    enrollmentDate: new Date().toISOString().split('T')[0],
    paidAmount: finalPrice,
    paymentStatus: "paid"
  };

  groupEnrollments.push(newEnrollment);
  grp.clientIds.push(clientId);

  if (disc > 0) {
    const promo = promoCodes.find(p => p.discountPercent === disc && p.isActive);
    if (promo) {
      promoCodeUsages.push({
        id: promoCodeUsages.length + 1,
        promoCodeId: promo.id,
        clientId,
        usedAt: new Date().toISOString(),
        discountApplied: wt.pricePerCycle - finalPrice
      });
    }
  }

  console.log(`[LOG - INFO] Важная запись в группу: Клиент ID ${clientId} записался в группу ID ${groupId}. Оплачено ${finalPrice} BYN`);

  res.json({
    message: "Вы успешно записаны и оплатили цикл групповых занятий",
    enrollment: newEnrollment,
    group: grp
  });
});

// Individual sessions bookings
app.get("/api/individual-sessions", (req: Request, res: Response) => {
  const responses = individualSessions.map(is => {
    const inst = instructors.find(i => i.id === is.instructorId);
    const trainerUser = inst ? users.find(u => u.id === inst.userId) : null;
    
    const cl = clients.find(c => c.id === is.clientId);
    const clientUser = cl ? users.find(u => u.id === cl.userId) : null;

    const wt = workoutTypes.find(w => w.id === is.workoutTypeId);

    return {
      ...is,
      instructorName: trainerUser ? trainerUser.fullName : "Инструктор",
      clientName: clientUser ? clientUser.fullName : "Клиент",
      clientAge: cl ? Math.abs(new Date(Date.now() - new Date(cl.dateOfBirth).getTime()).getUTCFullYear() - 1970) : 0,
      clientPhone: cl ? cl.phone : "",
      workoutTypeName: wt ? wt.name : "Индивидуальный сеанс"
    };
  });
  res.json(responses);
});

app.post("/api/individual-sessions/book", (req: Request, res: Response) => {
  const { clientId, instructorId, workoutTypeId, datetime, durationMinutes, discountPercent } = req.body;
  
  if (!clientId || !instructorId || !workoutTypeId || !datetime || !durationMinutes) {
    return res.status(400).json({ error: "Заполните параметры записи" });
  }

  const cl = clients.find(c => c.id === clientId);
  if (!cl) return res.status(404).json({ error: "Клиент не найден" });

  const inst = instructors.find(i => i.id === instructorId);
  if (!inst) return res.status(404).json({ error: "Инструктор не найден" });

  const wt = workoutTypes.find(w => w.id === workoutTypeId && w.category === "individual");
  if (!wt) return res.status(404).json({ error: "Выбран неподходящий или несуществующий тип тренировки" });

  // Time overlap validation
  const newStart = new Date(datetime).getTime();
  const newEnd = newStart + parseInt(durationMinutes) * 60 * 1000;

  const overlappingSession = individualSessions.find(s => {
    if (s.status === "cancelled") return false;
    if (s.instructorId !== parseInt(instructorId) && s.clientId !== parseInt(clientId)) return false;
    const sStart = new Date(s.datetime).getTime();
    const sEnd = sStart + s.durationMinutes * 60 * 1000;
    return (newStart < sEnd && newEnd > sStart);
  });

  if (overlappingSession) {
    return res.status(400).json({ error: "Предупреждение: у тренера или у вас уже есть запланированное занятие на это время" });
  }

  // Apply discount calculation
  const disc = discountPercent || 0;
  const basePrice = wt.pricePerSession;
  const finalPrice = Math.round(basePrice * (1 - disc / 100));

  const newSession: IndividualSession = {
    id: individualSessions.length + 1,
    clientId: parseInt(clientId),
    instructorId: parseInt(instructorId),
    workoutTypeId: parseInt(workoutTypeId),
    datetime,
    durationMinutes: parseInt(durationMinutes),
    price: finalPrice,
    status: "scheduled"
  };

  individualSessions.push(newSession);

  if (disc > 0) {
    const promo = promoCodes.find(p => p.discountPercent === disc && p.isActive);
    if (promo) {
      promoCodeUsages.push({
        id: promoCodeUsages.length + 1,
        promoCodeId: promo.id,
        clientId,
        usedAt: new Date().toISOString(),
        discountApplied: basePrice - finalPrice
      });
    }
  }

  console.log(`[LOG - INFO] Запись на разовую тренировку: Клиент ID ${clientId} записался к тренеру ID ${instructorId} на ${datetime}`);

  res.status(201).json(newSession);
});

// Cancel booking (with check deadline >= 12 hours)
app.post("/api/individual-sessions/cancel", (req: Request, res: Response) => {
  const { sessionId } = req.body;
  if (!sessionId) {
    return res.status(400).json({ error: "Не передан ID сессии" });
  }

  const session = individualSessions.find(s => s.id === parseInt(sessionId));
  if (!session) {
    return res.status(404).json({ error: "Сессия для тренировки не найдена" });
  }

  // Validate cancellation threshold (12 hours)
  const classTime = new Date(session.datetime).getTime();
  const now = Date.now();
  const timeDifferenceHours = (classTime - now) / (1000 * 60 * 60);

  if (timeDifferenceHours < 12) {
    return res.status(400).json({ 
      error: "Отмена невозможна: до запланированного занятия осталось менее 12 часов. Сессия будет списана и подлежит оплате." 
    });
  }

  session.status = "cancelled";
  console.log(`[LOG - INFO] Отмена индивидуального занятия: ID тренировки ${sessionId} отменена`);
  res.json({ message: "Запись на тренировку успешно отменена", session });
});

// Mark class as done by instructor
app.post("/api/individual-sessions/complete", (req: Request, res: Response) => {
  const { sessionId } = req.body;
  const session = individualSessions.find(s => s.id === parseInt(sessionId));
  if (!session) {
    return res.status(404).json({ error: "Сессия не найдена" });
  }

  session.status = "completed";
  console.log(`[LOG - INFO] Клиентская тренировка завершена тренером: ID ${sessionId}`);
  res.json({ message: "Занятие отмечено как успешно проведенное", session });
});

// 4. Statistics computations (Superuser-only)
app.get("/api/admin/statistics", (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || authHeader !== "admin") {
    return res.status(403).json({ error: "Доступ запрещен. Требуются права суперпользователя." });
  }

  // A. Number of classes per groups (including future and past scheduled ones)
  const classesCountByGroup = groups.map(g => {
    const scCount = scheduledClasses.filter(sc => sc.groupId === g.id).length;
    return {
      groupName: g.name,
      count: scCount
    };
  });

  // B. Average & Median age of clients
  const clientAges = clients.map(c => {
    const dob = new Date(c.dateOfBirth);
    const ageDiff = Date.now() - dob.getTime();
    const ageDate = new Date(ageDiff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }).sort((a, b) => a - b);

  const averageAge = clientAges.reduce((sum, age) => sum + age, 0) / (clientAges.length || 1);
  
  let medianAge = 0;
  if (clientAges.length > 0) {
    const mid = Math.floor(clientAges.length / 2);
    medianAge = clientAges.length % 2 !== 0 ? clientAges[mid] : (clientAges[mid - 1] + clientAges[mid]) / 2;
  }

  // C. Master class popularity check (unique clients total count in group enrollments + individual training sessions)
  const popularityByWorkoutType = workoutTypes.map(wt => {
    // Collect client IDs
    const uniqueClients = new Set<number>();
    
    if (wt.category === "group") {
      // Find groups matching this type
      const matchingGroups = groups.filter(g => g.workoutTypeId === wt.id);
      matchingGroups.forEach(mg => {
        mg.clientIds.forEach(id => uniqueClients.add(id));
      });
    } else {
      // Individual sessions of this type
      const matchingSessions = individualSessions.filter(s => s.workoutTypeId === wt.id && s.status !== "cancelled");
      matchingSessions.forEach(ms => uniqueClients.add(ms.clientId));
    }

    return {
      workoutName: wt.name,
      uniqueClientsCount: uniqueClients.size
    };
  }).sort((a, b) => b.uniqueClientsCount - a.uniqueClientsCount);

  // D. Workout types profitability list
  const profitabilityByWorkoutType = workoutTypes.map(wt => {
    let revenue = 0;
    if (wt.category === "group") {
      const matchingGroups = groups.filter(g => g.workoutTypeId === wt.id);
      matchingGroups.forEach(mg => {
        const enrollments = groupEnrollments.filter(e => e.groupId === mg.id && e.paymentStatus === "paid");
        enrollments.forEach(e => { revenue += e.paidAmount; });
      });
    } else {
      const sessions = individualSessions.filter(s => s.workoutTypeId === wt.id && s.status === "completed");
      sessions.forEach(s => { revenue += s.price; });
    }

    return {
      workoutName: wt.name,
      revenue
    };
  }).sort((a, b) => b.revenue - a.revenue);

  // E. Table of clients in alphabetical order + sum of all their payments (cycles + individual sessions + club cards if any)
  const clientPayments = clients.map(c => {
    const userObj = users.find(u => u.id === c.userId);
    const fullName = userObj ? userObj.fullName : "Неизвестно";
    
    // Group payments
    const grpSum = groupEnrollments
      .filter(e => e.clientId === c.id && e.paymentStatus === "paid")
      .reduce((s, e) => s + e.paidAmount, 0);

    // Individual session payments
    const indSum = individualSessions
      .filter(e => e.clientId === c.id && e.status === "completed")
      .reduce((s, e) => s + e.price, 0);

    // Club Cards purchased
    const cardsSum = clubCards
      .filter(card => card.clientId === c.id)
      .reduce((s, card) => s + card.price, 0);

    return {
      clientId: c.id,
      fullName,
      phone: c.phone,
      totalPaid: grpSum + indSum + cardsSum,
      workoutSum: grpSum,
      individualSum: indSum,
      cardsSum
    };
  }).sort((a, b) => a.fullName.localeCompare(b.fullName));

  // F. Monthly revenue trends data (combining payments grouped by month of year 2026)
  const monthlyRevenue = [
    { month: "Январь", revenue: 1400 },
    { month: "Февраль", revenue: 1850 },
    { month: "Март", revenue: 2500 },
    { month: "Апрель", revenue: 3200 },
    { month: "Май (текущий)", revenue: 4180 }
  ];

  res.json({
    classesCountByGroup,
    ageStats: {
      average: Math.round(averageAge * 10) / 10,
      median: medianAge
    },
    popularityByWorkoutType,
    profitabilityByWorkoutType,
    clientPayments,
    monthlyRevenue
  });
});

// Admin action: Bulk raise prices for future individual training types
app.post("/api/admin/bulk-price-increase", (req: Request, res: Response) => {
  const { workoutTypeId, percentage } = req.body;
  
  if (!workoutTypeId || !percentage) {
    return res.status(400).json({ error: "Заполните необходимые аргументы" });
  }

  const wt = workoutTypes.find(w => w.id === parseInt(workoutTypeId));
  if (!wt) return res.status(404).json({ error: "Вид тренировки не найден" });

  const multiplier = 1 + parseFloat(percentage) / 100;
  
  if (wt.category === "individual") {
    const oldPrice = wt.pricePerSession;
    wt.pricePerSession = Math.round(wt.pricePerSession * multiplier);
    
    // Automatically recalculate future scheduled training sessions price for this type!
    let updatedCount = 0;
    individualSessions.forEach(s => {
      if (s.workoutTypeId === wt.id && s.status === "scheduled") {
        s.price = Math.round(s.price * multiplier);
        updatedCount++;
      }
    });

    console.log(`[LOG - WARNING] Массовый пересчет цен superuser: тип тренировки ${wt.id} повышен в цене на ${percentage}%. Изменен ${updatedCount} будущих сессий.`);
    return res.json({ 
      message: `Стоимость "${wt.name}" увеличена с ${oldPrice} до ${wt.pricePerSession} BYN. Обновлено ${updatedCount} запланированных тренировок.` 
    });
  } else {
    // Group type bulk price change
    const oldCyclePrice = wt.pricePerCycle;
    wt.pricePerCycle = Math.round(wt.pricePerCycle * multiplier);
    return res.json({ 
      message: `Стоимость группового цикла "${wt.name}" увеличена с ${oldCyclePrice} до ${wt.pricePerCycle} BYN.` 
    });
  }
});


// Dev/production deployment handling
async function init() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

init();
