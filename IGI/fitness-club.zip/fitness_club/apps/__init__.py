# Empty apps init
