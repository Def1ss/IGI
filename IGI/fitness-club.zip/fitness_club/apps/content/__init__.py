# Empty content app init
