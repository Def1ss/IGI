# Empty reviews app init
