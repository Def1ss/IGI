# Empty analytics app init
