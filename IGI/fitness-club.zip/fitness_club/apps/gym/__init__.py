# Empty gym app init
