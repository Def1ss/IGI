from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Admin Panel
    path('admin/', admin.site.urls),
    
    # Public & client views routed across app namespaces
    path('', include('apps.content.urls')),       # /, /about/, /news/, /faq/, /contacts/, /privacy/, /vacancies/
    path('reviews/', include('apps.reviews.urls')), # /reviews/
    path('promocodes/', include('apps.promocodes.urls')), # /promocodes/
    path('schedule/', include('apps.workouts.urls')), # /schedule/
    path('profile/', include('apps.users.urls')), # /profile/
    path('statistics/', include('apps.analytics.urls')), # /statistics/
    path('individual/sessions/', include('apps.enrollments.urls')), # /individual/sessions/
]
