// Shared types for Fitness Club Application

export interface User {
  id: number;
  username: string;
  email: string;
  role: "admin" | "instructor" | "client";
  fullName: string;
}

export interface ClientProfile {
  id: number;
  userId: number;
  dateOfBirth: string;
  phone: string;
  address: string;
  registrationDate: string;
  clubCardId: number | null;
}

export interface InstructorProfile {
  id: number;
  userId: number;
  specializationIds: number[];
  experienceYears: number;
  photoUrl: string;
  hireDate: string;
}

export interface WorkoutType {
  id: number;
  name: string;
  description: string;
  pricePerSession: number;
  pricePerCycle: number;
  category: "group" | "individual";
}

export interface Group {
  id: number;
  name: string;
  workoutTypeId: number;
  instructors: { instructorId: number; role: "main" | "assistant" }[];
  clientIds: number[];
  workoutType?: WorkoutType;
  instructorsEnriched?: {
    instructorId: number;
    role: "main" | "assistant";
    fullName: string;
  }[];
}

export interface ScheduledClass {
  id: number;
  groupId: number;
  startTime: string;
  endTime: string;
  hallId: number;
  instructorIds: number[];
  groupName?: string;
  workoutTypeName?: string;
  pricePerCycle?: number;
  hallName?: string;
  instructorNames?: string[];
}

export interface IndividualSession {
  id: number;
  clientId: number;
  instructorId: number;
  workoutTypeId: number;
  datetime: string;
  durationMinutes: number;
  price: number;
  status: "scheduled" | "completed" | "cancelled";
  instructorName?: string;
  clientName?: string;
  clientAge?: number;
  clientPhone?: string;
  workoutTypeName?: string;
}

export interface ClubCard {
  id: number;
  cardType: "monthly" | "yearly" | "trial";
  price: number;
  validFrom: string;
  validTo: string;
  clientId: number | null;
}

export interface PromoCode {
  id: number;
  code: string;
  discountPercent: number;
  validFrom: string;
  validTo: string;
  isActive: boolean;
  applicableTo: "group" | "individual" | "club_card" | "all";
}

export interface NewsItem {
  id: number;
  title: string;
  slug: string;
  summary: string;
  fullText: string;
  imageUrl: string;
  publishedDate: string;
  authorId: number;
}

export interface Review {
  id: number;
  clientId: number;
  rating: number;
  text: string;
  createdAt: string;
  clientName?: string;
}

export interface Vacancy {
  id: number;
  position: string;
  description: string;
  salary?: string;
  isActive: boolean;
}

export interface FAQItem {
  id: number;
  question: string;
  answer: string;
  addedDate: string;
}

export interface ContactPerson {
  id: number;
  fullName: string;
  role: string;
  phone: string;
  email: string;
  imageUrl: string;
}

export interface CompanyHistory {
  id: number;
  year: number;
  event: string;
}

export interface StatisticsData {
  classesCountByGroup: { groupName: string; count: number }[];
  ageStats: { average: number; median: number };
  popularityByWorkoutType: { workoutName: string; uniqueClientsCount: number }[];
  profitabilityByWorkoutType: { workoutName: string; revenue: number }[];
  clientPayments: {
    clientId: number;
    fullName: string;
    phone: string;
    totalPaid: number;
    workoutSum: number;
    individualSum: number;
    cardsSum: number;
  }[];
  monthlyRevenue: { month: string; revenue: number }[];
}
