import React, { useState, useEffect } from "react";
import {
  Activity,
  Calendar,
  Clock,
  Heart,
  HelpCircle,
  Info,
  MapPin,
  MessageSquare,
  Newspaper,
  Phone,
  Shield,
  Tag,
  TrendingUp,
  User as UserIcon,
  Users,
  LogOut,
  Lock,
  Plus,
  CheckCircle2,
  AlertCircle,
  DollarSign,
  ChevronRight,
  Filter,
  Trash2,
  Sparkles,
  Award,
  ArrowRight
} from "lucide-react";

import {
  User,
  ClientProfile,
  InstructorProfile,
  WorkoutType,
  Group,
  ScheduledClass,
  IndividualSession,
  ClubCard,
  PromoCode,
  NewsItem,
  Review,
  Vacancy,
  FAQItem,
  ContactPerson,
  CompanyHistory,
  StatisticsData
} from "./types";
import { users, instructors, gymHalls, equipments } from "./staticData";

export default function App() {
  // Page State Simulation
  const [currentPage, setCurrentPage] = useState<string>("main");
  const [selectedNewsSlug, setSelectedNewsSlug] = useState<string | null>(null);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentClient, setCurrentClient] = useState<ClientProfile | null>(null);
  const [currentInstructor, setCurrentInstructor] = useState<InstructorProfile | null>(null);
  
  // Login / Register Form states
  const [authMode, setAuthMode] = useState<"login" | "register" | null>(null);
  const [loginUsername, setLoginUsername] = useState("");
  const [authError, setAuthError] = useState("");
  
  const [registerForm, setRegisterForm] = useState({
    username: "",
    email: "",
    fullName: "",
    dateOfBirth: "",
    phone: "",
    address: ""
  });

  // Currency Switching State
  const [currency, setCurrency] = useState<"BYN" | "USD" | "EUR">("BYN");
  const [rates, setRates] = useState<any>({ BYN: 3.25, EUR: 0.92, USD: 1.0 });

  // Feed/DB States from API
  const [news, setNews] = useState<NewsItem[]>([]);
  const [vacancies, setVacancies] = useState<Vacancy[]>([]);
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [contacts, setContacts] = useState<ContactPerson[]>([]);
  const [history, setHistory] = useState<CompanyHistory[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [activePromoCodes, setActivePromoCodes] = useState<PromoCode[]>([]);
  const [workoutTypes, setWorkoutTypes] = useState<WorkoutType[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [schedule, setSchedule] = useState<ScheduledClass[]>([]);
  const [individualSessions, setIndividualSessions] = useState<IndividualSession[]>([]);
  const [statistics, setStatistics] = useState<StatisticsData | null>(null);

  // Filters for Schedule page
  const [schedFilterDate, setSchedFilterDate] = useState<string>("");
  const [schedFilterGroup, setSchedFilterGroup] = useState<string>("");
  const [schedFilterHall, setSchedFilterHall] = useState<string>("");
  const [schedSearchQuery, setSchedSearchQuery] = useState<string>("");

  // Booking process states
  const [bookingInstructorId, setBookingInstructorId] = useState<string>("");
  const [bookingWorkoutTypeId, setBookingWorkoutTypeId] = useState<string>("");
  const [bookingDatetime, setBookingDatetime] = useState<string>("");
  const [bookingDuration, setBookingDuration] = useState<number>(60);
  const [bookingPromoCode, setBookingPromoCode] = useState<string>("");
  const [bookingAppliedDiscount, setBookingAppliedDiscount] = useState<number>(0);
  const [bookingMessage, setBookingMessage] = useState<string>("");
  const [bookingError, setBookingError] = useState<string>("");

  // Review submission state
  const [newReviewRating, setNewReviewRating] = useState<number>(5);
  const [newReviewText, setNewReviewText] = useState<string>("");
  const [reviewSubmitMessage, setReviewSubmitMessage] = useState<string>("");

  // Superuser action states
  const [bulkPriceId, setBulkPriceId] = useState<string>("");
  const [bulkPricePercent, setBulkPricePercent] = useState<number>(10);
  const [bulkMessage, setBulkMessage] = useState<string>("");

  // General App clock (User timezone / UTC timezone switchable)
  const [timeMode, setTimeMode] = useState<"local" | "utc">("local");
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  // Random quote of day state
  const [motivationQuote, setMotivationQuote] = useState<{ quote: string; author: string } | null>(null);

  // Keep digital clock ticking
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Sync session and initial loads
  useEffect(() => {
    loadPublicFeeds();
    fetchMotivationQuote("guest");
    
    // Check local storage for persistent session
    const storedUser = localStorage.getItem("fitness_user");
    const storedClient = localStorage.getItem("fitness_client");
    const storedInstructor = localStorage.getItem("fitness_instructor");
    
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setCurrentUser(parsedUser);
      if (storedClient) setCurrentClient(JSON.parse(storedClient));
      if (storedInstructor) setCurrentInstructor(JSON.parse(storedInstructor));
      
      // Load currency and quote
      fetchExchangeRates(parsedUser.username);
      fetchMotivationQuote(parsedUser.username);
    }
  }, []);

  // Fetch stats when admin page opened
  useEffect(() => {
    if (currentPage === "statistics" && currentUser?.role === "admin") {
      fetchAdminStatistics();
    }
    if (currentPage === "individual-sessions") {
      loadIndividualSessions();
    }
  }, [currentPage, currentUser]);

  const loadPublicFeeds = async () => {
    try {
      const resNews = await fetch("/api/news");
      if (resNews.ok) setNews(await resNews.json());

      const resVacancies = await fetch("/api/vacancies");
      if (resVacancies.ok) setVacancies(await resVacancies.json());

      const resFaqs = await fetch("/api/faqs");
      if (resFaqs.ok) setFaqs(await resFaqs.json());

      const resContacts = await fetch("/api/contacts");
      if (resContacts.ok) setContacts(await resContacts.json());

      const resHistory = await fetch("/api/about/history");
      if (resHistory.ok) setHistory(await resHistory.json());

      const resReviews = await fetch("/api/reviews");
      if (resReviews.ok) setReviews(await resReviews.json());

      const resPromo = await fetch("/api/promocodes");
      if (resPromo.ok) setActivePromoCodes(await resPromo.json());

      const resWorkout = await fetch("/api/workout-types");
      if (resWorkout.ok) setWorkoutTypes(await resWorkout.json());

      const resGroups = await fetch("/api/groups");
      if (resGroups.ok) setGroups(await resGroups.json());

      const resSchedule = await fetch("/api/schedule");
      if (resSchedule.ok) setSchedule(await resSchedule.json());
    } catch (e) {
      console.error("Failed to load public feeds", e);
    }
  };

  const loadIndividualSessions = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/individual-sessions");
      if (res.ok) {
        const allSessions: IndividualSession[] = await res.json();
        // filter client or instructor sessions
        if (currentUser.role === "client" && currentClient) {
          setIndividualSessions(allSessions.filter(s => s.clientId === currentClient.id));
        } else if (currentUser.role === "instructor" && currentInstructor) {
          setIndividualSessions(allSessions.filter(s => s.instructorId === currentInstructor.id));
        } else {
          setIndividualSessions(allSessions);
        }
      }
    } catch (e) {
      console.error("Error loading individual sessions", e);
    }
  };

  const fetchExchangeRates = async (username: string) => {
    try {
      const res = await fetch("/api/exchange-rate", {
        headers: { "Authorization": username }
      });
      if (res.ok) {
        setRates(await res.json());
      }
    } catch (e) {
      console.error("Error fetching rates", e);
    }
  };

  const fetchMotivationQuote = async (username: string = "guest") => {
    try {
      const res = await fetch("/api/motivation", {
        headers: { "Authorization": username }
      });
      if (res.ok) {
        setMotivationQuote(await res.json());
      }
    } catch (e) {
      console.error("Error fetching quotes", e);
    }
  };

  const fetchAdminStatistics = async () => {
    try {
      const res = await fetch("/api/admin/statistics", {
        headers: { "Authorization": "admin" }
      });
      if (res.ok) {
        setStatistics(await res.json());
      }
    } catch (e) {
      console.error("Error loading statistics", e);
    }
  };

  // Convert prices in standard BYN to selected currency
  const convertPrice = (priceInByn: number): string => {
    const rateByn = rates.BYN || 3.25;
    const priceInUsd = priceInByn / rateByn;
    if (currency === "USD") {
      return `${priceInUsd.toFixed(2)} USD`;
    }
    if (currency === "EUR") {
      const priceInEur = priceInUsd * (rates.EUR || 0.92);
      return `${priceInEur.toFixed(2)} EUR`;
    }
    return `${priceInByn.toFixed(2)} BYN`;
  };

  // Login action
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: loginUsername })
      });
      const data = await res.json();
      if (res.ok) {
        setCurrentUser(data.user);
        if (data.client) {
          setCurrentClient(data.client);
          localStorage.setItem("fitness_client", JSON.stringify(data.client));
        }
        if (data.instructor) {
          setCurrentInstructor(data.instructor);
          localStorage.setItem("fitness_instructor", JSON.stringify(data.instructor));
        }
        localStorage.setItem("fitness_user", JSON.stringify(data.user));
        
        setAuthMode(null);
        setLoginUsername("");
        fetchExchangeRates(data.user.username);
        fetchMotivationQuote(data.user.username);
      } else {
        setAuthError(data.error || "Ошибка авторизации");
      }
    } catch (e) {
      setAuthError("Сетевая ошибка при логине");
    }
  };

  // Register action
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(registerForm)
      });
      const data = await res.json();
      if (res.ok) {
        setCurrentUser(data.user);
        setCurrentClient(data.client);
        localStorage.setItem("fitness_user", JSON.stringify(data.user));
        localStorage.setItem("fitness_client", JSON.stringify(data.client));
        setAuthMode(null);
        setRegisterForm({
          username: "",
          email: "",
          fullName: "",
          dateOfBirth: "",
          phone: "",
          address: ""
        });
        fetchExchangeRates(data.user.username);
        fetchMotivationQuote(data.user.username);
      } else {
        setAuthError(data.error || "Ошибка регистрации");
      }
    } catch (e) {
      setAuthError("Сетевая ошибка регистрации");
    }
  };

  // Logout action
  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentClient(null);
    setCurrentInstructor(null);
    setMotivationQuote(null);
    
    localStorage.removeItem("fitness_user");
    localStorage.removeItem("fitness_client");
    localStorage.removeItem("fitness_instructor");
    
    setCurrency("BYN");
    setCurrentPage("main");
  };

  // Buy Club Card Action
  const handlePurchaseCard = async (cardType: "monthly" | "yearly" | "trial", rawPrice: number) => {
    if (!currentUser || !currentClient) return;
    try {
      const res = await fetch("/api/club-cards/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: currentClient.id,
          cardType,
          price: rawPrice
        })
      });
      const data = await res.json();
      if (res.ok) {
        setCurrentClient(data.client);
        localStorage.setItem("fitness_client", JSON.stringify(data.client));
        alert(`Поздравляем! Абонемент "${cardType}" успешно активирован в вашей учетной записи.`);
        loadPublicFeeds();
      } else {
        alert(data.error || "Ошибка при покупке абонемента");
      }
    } catch (e) {
      alert("Сетевая ошибка при оформлении карты");
    }
  };

  // Group booking flow
  const handleEnrollGroup = async (groupId: number, discountPercent: number = 0) => {
    if (!currentUser || !currentClient) {
      alert("Пожалуйста, войдите в систему перед записью на групповое занятие!");
      return;
    }
    
    // Check if client has a club card at all
    if (!currentClient.clubCardId) {
      alert("Внимание: Для записи на групповой цикл занятий у вас должен быть активный абонемент (клубная карта). Пожалуйста, приобретите карту во вкладке профиля!");
      return;
    }

    try {
      const res = await fetch("/api/groups/enroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: currentClient.id,
          groupId,
          discountPercent
        })
      });
      const data = await res.json();
      if (res.ok) {
        alert("Запись оформлена! Весь цикл тренировок оплачен. Проверьте расписание в личном кабинете.");
        loadPublicFeeds();
      } else {
        alert(data.error || "Ошибка при регистрации в группу");
      }
    } catch (e) {
      alert("Ошибка сети при отправке данных");
    }
  };

  // Validation of Booking Promo Code
  const handleValidatePromo = async () => {
    setBookingError("");
    setBookingMessage("");
    if (!bookingPromoCode) return;
    try {
      const res = await fetch("/api/promocodes/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: bookingPromoCode,
          type: "individual",
          clientId: currentClient?.id
        })
      });
      const data = await res.json();
      if (res.ok) {
        setBookingAppliedDiscount(data.discountPercent);
        setBookingMessage(`Промокод применен успешно! Скидка ${data.discountPercent}%`);
      } else {
        setBookingAppliedDiscount(0);
        setBookingError(data.error || "Недействительный промокод");
      }
    } catch (e) {
      setBookingError("Сетевая ошибка при проверке промокода");
    }
  };

  // Book Individual Session
  const handleBookIndividual = async (e: React.FormEvent) => {
    e.preventDefault();
    setBookingError("");
    setBookingMessage("");

    if (!currentUser || !currentClient) {
      setBookingError("Войдите как клиент, чтобы забронировать тренировку");
      return;
    }

    try {
      const res = await fetch("/api/individual-sessions/book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: currentClient.id,
          instructorId: bookingInstructorId,
          workoutTypeId: bookingWorkoutTypeId,
          datetime: bookingDatetime,
          durationMinutes: bookingDuration,
          discountPercent: bookingAppliedDiscount
        })
      });
      const data = await res.json();
      if (res.ok) {
        setBookingMessage("Запись успешно зарегистрирована у инструктора!");
        setBookingInstructorId("");
        setBookingWorkoutTypeId("");
        setBookingDatetime("");
        setBookingPromoCode("");
        setBookingAppliedDiscount(0);
        loadIndividualSessions();
      } else {
        setBookingError(data.error || "Ошибка бронирования");
      }
    } catch (err) {
      setBookingError("Сетевая ошибка сохранения тренировки");
    }
  };

  // Cancel Individual session
  const handleCancelSession = async (sessionId: number) => {
    if (!confirm("Вы действительно хотите отменить эту персональную тренировку?")) return;
    try {
      const res = await fetch("/api/individual-sessions/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId })
      });
      if (res.ok) {
        alert("Занятие успешно отменено.");
        loadIndividualSessions();
      } else {
        const data = await res.json();
        alert(data.error || "Ошибка при отмене");
      }
    } catch (e) {
      alert("Сетевая ошибка");
    }
  };

  // Instructor complete session mark
  const handleCompleteSession = async (sessionId: number) => {
    try {
      const res = await fetch("/api/individual-sessions/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId })
      });
      if (res.ok) {
        alert("Занятие отмечено как успешно проведенное!");
        loadIndividualSessions();
      } else {
        const data = await res.json();
        alert(data.error || "Ошибка");
      }
    } catch (e) {
      alert("Ошибка сети");
    }
  };

  // Review submit
  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setReviewSubmitMessage("");
    if (!currentUser || !currentClient) return;

    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: currentClient.id,
          rating: newReviewRating,
          text: newReviewText
        })
      });
      if (res.ok) {
        setNewReviewText("");
        setReviewSubmitMessage("Спасибо! Ваш отзыв успешно опубликован после тренировки.");
        loadPublicFeeds();
      } else {
        const data = await res.json();
        setReviewSubmitMessage(`Ошибка: ${data.error}`);
      }
    } catch (e) {
      setReviewSubmitMessage("Сетевая ошибка при публикации");
    }
  };

  // Bulk Price increase action
  const handleBulkPriceIncrease = async (e: React.FormEvent) => {
    e.preventDefault();
    setBulkMessage("");
    try {
      const res = await fetch("/api/admin/bulk-price-increase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          workoutTypeId: bulkPriceId,
          percentage: bulkPricePercent
        })
      });
      const data = await res.json();
      if (res.ok) {
        setBulkMessage(data.message);
        loadPublicFeeds();
        fetchAdminStatistics();
      } else {
        setBulkMessage(`Ошибка: ${data.error}`);
      }
    } catch (e) {
      setBulkMessage("Ошибка сети");
    }
  };

  // Helpers to fetch names for lookups
  const getUserName = (userId: number): string => {
    const user = users.find(u => u.id === userId);
    return user ? user.fullName : "Инструктор";
  };

  const getTrainerName = (instructorId: number): string => {
    const inst = instructors.find(i => i.id === instructorId);
    if (!inst) return "Неизвестный тренер";
    return getUserName(inst.userId);
  };

  // Schedule filtering logic
  const filteredSchedule = schedule.filter(sc => {
    let groupMatches = true;
    if (schedFilterGroup) {
      groupMatches = sc.groupId.toString() === schedFilterGroup;
    }

    let hallMatches = true;
    if (schedFilterHall) {
      hallMatches = sc.hallId.toString() === schedFilterHall;
    }

    let dateMatches = true;
    if (schedFilterDate) {
      dateMatches = sc.startTime.startsWith(schedFilterDate);
    }

    let searchMatches = true;
    if (schedSearchQuery.trim() !== "") {
      const q = schedSearchQuery.toLowerCase();
      const groupNameOk = sc.groupName?.toLowerCase().includes(q);
      const exerciseTypeOk = sc.workoutTypeName?.toLowerCase().includes(q);
      const instOk = sc.instructorNames?.some(name => name.toLowerCase().includes(q));
      searchMatches = !!(groupNameOk || exerciseTypeOk || instOk);
    }

    return groupMatches && hallMatches && dateMatches && searchMatches;
  });

  return (
    <div style={{ margin: "16px auto", maxWidth: "900px", fontFamily: "monospace" }}>
      {/* HEADER BAR */}
      <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
        <tbody>
          <tr>
            <td align="left">
              <strong>ФИТНЕС-КЛУБ «ФОРСАЖ»</strong>
              <br />
              <small>ФИТНЕС ДЛЯ ПРОФЕССИОНАЛОВ (API MOTIVATION COMPLIANT)</small>
            </td>
            <td align="right">
              {currentTime ? (
                <div>
                  ⏰ Время ({timeMode === "local" ? "Локальное" : "UTC"}):{" "}
                  <strong>
                    {timeMode === "local"
                      ? currentTime.toLocaleString("ru-RU")
                      : currentTime.toISOString().replace("T", " ").substring(0, 19)}
                  </strong>{" "}
                  [
                  <button onClick={() => setTimeMode(timeMode === "local" ? "utc" : "local")}>
                    Сменить
                  </button>
                  ]
                </div>
              ) : null}
            </td>
          </tr>
        </tbody>
      </table>

      {/* CHANGER OR USER WELCOME CARD */}
      <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
        <tbody>
          <tr>
            {currentUser ? (
              <td>
                👤 Добро пожаловать, <strong>{currentUser.fullName}</strong> (
                {currentUser.role === "admin"
                  ? "Администратор"
                  : currentUser.role === "instructor"
                  ? "Инструктор"
                  : "Клиент клуба"}
                )!{" "}
                {currentUser ? (
                  <span>
                    Валюта:{" "}
                    {(["BYN", "USD", "EUR"] as const).map(cur => (
                      <span key={cur} style={{ margin: "0 4px" }}>
                        <button
                          disabled={currency === cur}
                          onClick={() => setCurrency(cur)}
                        >
                          {cur}
                        </button>
                      </span>
                    ))}
                  </span>
                ) : null}
                <button style={{ marginLeft: "15px" }} onClick={handleLogout}>
                  Выйти из системы
                </button>
              </td>
            ) : (
              <td>
                👤 Вы просматриваете сайт как Гость. Пожалуйста, авторизуйтесь для доступа к бронированию.{" "}
                <button onClick={() => { setAuthError(""); setAuthMode("login"); }}>
                  Войти
                </button>{" "}
                или{" "}
                <button onClick={() => { setAuthError(""); setAuthMode("register"); }}>
                  Регистрация
                </button>
              </td>
            )}
          </tr>
        </tbody>
      </table>

      {/* MOTIVATIONAL QUOTE API DISPLAY AT THE TOP */}
      {motivationQuote && (
        <fieldset style={{ marginBottom: "16px", background: "#fcfcfc" }}>
          <legend><strong>💡 Ежедневная Мотивация от API</strong></legend>
          <blockquote style={{ margin: "4px 10px", fontStyle: "italic" }}>
            «{motivationQuote.quote}»
          </blockquote>
          <div style={{ textAlign: "right" }}>
            <small>— {motivationQuote.author}</small>
          </div>
        </fieldset>
      )}

      {/* MAIN AUTH DIALOG CONTEXTS */}
      {authMode === "login" && (
        <fieldset style={{ marginBottom: "16px" }}>
          <legend><strong>Авторизация в системе</strong></legend>
          <form onSubmit={handleLogin}>
            <p>
              Введите Имя пользователя или Email:{" "}
              <input
                type="text"
                value={loginUsername}
                onChange={e => setLoginUsername(e.target.value)}
                required
                placeholder="Например, trainer_pavel или admin"
              />
            </p>
            {authError && <p style={{ color: "red" }}>⚠️ {authError}</p>}
            <p>
              <button type="submit">Войти</button>{" "}
              <button type="button" onClick={() => setAuthMode(null)}>Отмена</button>
            </p>
            <hr />
            <p>
              <small>
                Рекомендация для теста: воспользуйтесь встроенными пользователями <strong>admin</strong>, <strong>trainer_pavel</strong>.
              </small>
            </p>
          </form>
        </fieldset>
      )}

      {authMode === "register" && (
        <fieldset style={{ marginBottom: "16px" }}>
          <legend><strong>Регистрация нового Члена Клуба (18+)</strong></legend>
          <form onSubmit={handleRegister}>
            <p>
              Логин (Имя пользователя):{" "}
              <input
                type="text"
                required
                value={registerForm.username}
                onChange={e => setRegisterForm({ ...registerForm, username: e.target.value })}
              />
            </p>
            <p>
              Электронная почта:{" "}
              <input
                type="email"
                required
                value={registerForm.email}
                onChange={e => setRegisterForm({ ...registerForm, email: e.target.value })}
              />
            </p>
            <p>
              ФИО полностью:{" "}
              <input
                type="text"
                required
                value={registerForm.fullName}
                placeholder="Иванов Иван Иванович"
                onChange={e => setRegisterForm({ ...registerForm, fullName: e.target.value })}
              />
            </p>
            <p>
              Дата рождения (строго 18+):{" "}
              <input
                type="date"
                required
                value={registerForm.dateOfBirth}
                onChange={e => setRegisterForm({ ...registerForm, dateOfBirth: e.target.value })}
              />
            </p>
            <p>
              Номер контактного телефона (РБ):{" "}
              <input
                type="text"
                required
                value={registerForm.phone}
                placeholder="+375XXXXXXXXX"
                onChange={e => setRegisterForm({ ...registerForm, phone: e.target.value })}
              />
            </p>
            <p>
              Адрес проживания:{" "}
              <input
                type="text"
                required
                value={registerForm.address}
                onChange={e => setRegisterForm({ ...registerForm, address: e.target.value })}
              />
            </p>
            {authError && <p style={{ color: "red" }}>⚠️ {authError}</p>}
            <p>
              <button type="submit">Зарегистрироваться</button>{" "}
              <button type="button" onClick={() => setAuthMode(null)}>Отмена</button>
            </p>
          </form>
        </fieldset>
      )}

      {/* CORE MENU NAVIGATION TABS */}
      <table border={1} cellPadding={6} style={{ width: "100%", marginBottom: "16px", textAlign: "center" }}>
        <tbody>
          <tr>
            <td>
              <button onClick={() => { setCurrentPage("main"); setSelectedNewsSlug(null); }}>Главная</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("about")}>О компании</button>
            </td>
            <td>
              <button onClick={() => { setCurrentPage("news"); setSelectedNewsSlug(null); }}>Новости</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("schedule")}>Расписание</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("individual-sessions")}>Индивидуальные</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("promocodes")}>Промокоды</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("vacancies")}>Вакансии</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("reviews")}>Отзывы</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("faq")}>Вопросы-ответы</button>
            </td>
            <td>
              <button onClick={() => setCurrentPage("contacts")}>Контакты</button>
            </td>
            <td>
              <button onClick={() => {
                if (!currentUser) {
                  setAuthError("Для доступа необходимо авторизоваться");
                  setAuthMode("login");
                } else {
                  setCurrentPage("profile");
                }
              }}>Личный кабинет</button>
            </td>
            {currentUser?.role === "admin" && (
              <td style={{ backgroundColor: "#ffffe0" }}>
                <button onClick={() => setCurrentPage("statistics")}><strong>Аналитика (Admin)</strong></button>
              </td>
            )}
          </tr>
        </tbody>
      </table>

      {/* DYNAMIC PAGES CONTAINER */}
      <div>
        {/* 1. MAIN PAGE VIEW */}
        {currentPage === "main" && (
          <div>
            <h3>Добро пожаловать в фитнес-клуб «ФОРСАЖ»!</h3>
            <p>
              Форсаж — это спортивное пространство премиум-класса на чистом HTML, спроектированное для профессиональных атлетов и любителей здорового образа жизни.
              Мы предлагаем передовое оборудование, лучших тренеров и удобную систему записи.
            </p>
            <p>
              Ниже вы можете ознакомиться со списком наших залов и установленным спортивным инвентарем.
            </p>

            <h4>Наши Спортивные Залы</h4>
            {gymHalls.map(hall => (
              <fieldset key={hall.id} style={{ marginBottom: "12px" }}>
                <legend><strong>{hall.name}</strong></legend>
                <p>Максимальная вместимость: до {hall.capacity} спортсменов</p>
                <strong>Доступный инвентарь в зале:</strong>
                <ul>
                  {hall.equipments.map(he => {
                    const eq = equipments.find(e => e.id === he.equipmentId);
                    return (
                      <li key={he.equipmentId}>
                        {eq ? eq.name : "Снаряд"} — {he.quantity} шт. (<small>тип: {eq ? eq.type : "спорт инвентарь"}</small>)
                      </li>
                    );
                  })}
                </ul>
              </fieldset>
            ))}

            <p>
              <em>* Всё установленное оборудование сертифицировано и проходит регулярный технический осмотр.</em>
            </p>
          </div>
        )}

        {/* 2. ABOUT PAGE VIEW */}
        {currentPage === "about" && (
          <div>
            <h3>История компании</h3>
            <p>
              Фитнес-клуб «ФОРСАЖ» зародился как проект профессиональных спортсменов, стремящихся поднять планку фитнес-услуг на качественно новый уровень.
            </p>
            <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
              <thead>
                <tr style={{ backgroundColor: "#f2f2f2" }}>
                  <th>Год</th>
                  <th>Событие в истории клуба</th>
                </tr>
              </thead>
              <tbody>
                {history.map(item => (
                  <tr key={item.id}>
                    <td><strong>{item.year} год</strong></td>
                    <td>{item.event}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h3>Наша отличная команда инструкторов</h3>
            <p>Наши тренеры имеют многолетний соревновательный и педагогический стаж:</p>
            {instructors.map(inst => (
              <fieldset key={inst.id} style={{ marginBottom: "12px" }}>
                <legend><strong>{getUserName(inst.userId)}</strong></legend>
                <table border={0} cellPadding={4}>
                  <tbody>
                    <tr>
                      <td valign="top">
                        {inst.photoUrl && (
                          <img
                            src={inst.photoUrl}
                            alt="Instructor photo"
                            width="100"
                            style={{ border: "2px solid #ccc" }}
                            referrerPolicy="no-referrer"
                          />
                        )}
                      </td>
                      <td valign="top" style={{ paddingLeft: "15px" }}>
                        <p>Опыт работы: <strong>{inst.experienceYears} лет</strong></p>
                        <p>Дата приема на работу: {inst.hireDate}</p>
                        <p>
                          Специализация в клубе:{" "}
                          <strong>
                            {inst.specializationIds.map(id => {
                              const wt = workoutTypes.find(w => w.id === id);
                              return wt ? wt.name : `Спец-${id}`;
                            }).join(", ")}
                          </strong>
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </fieldset>
            ))}
          </div>
        )}

        {/* 3. NEWS PAGE VIEW */}
        {currentPage === "news" && (
          <div>
            {selectedNewsSlug ? (
              <div>
                {/* News Details */}
                {(() => {
                  const article = news.find(n => n.slug === selectedNewsSlug);
                  if (!article) return <p>Статья не найдена...</p>;
                  return (
                    <div>
                      <button onClick={() => setSelectedNewsSlug(null)}>← Вернуться к списку новостей</button>
                      <hr />
                      <h3>{article.title}</h3>
                      <p><small>Опубликовано: {article.publishedDate}</small></p>
                      {article.imageUrl && (
                        <p>
                          <img
                            src={article.imageUrl}
                            alt="News concept"
                            style={{ maxWidth: "100%", height: "auto" }}
                            referrerPolicy="no-referrer"
                          />
                        </p>
                      )}
                      <p style={{ whiteSpace: "pre-wrap", lineHeight: "1.6" }}>{article.fullText}</p>
                      <hr />
                      <button onClick={() => setSelectedNewsSlug(null)}>← Вернуться к списку новостей</button>
                    </div>
                  );
                })()}
              </div>
            ) : (
              <div>
                <h3>Новости фитнес-клуба</h3>
                <p>Свежие сообщения, обновления, и события в нашем комплексе:</p>
                {news.map(n => (
                  <fieldset key={n.id} style={{ marginBottom: "16px" }}>
                    <legend><strong>{n.title}</strong></legend>
                    <p><small>Дата: {n.publishedDate}</small></p>
                    <p>{n.summary}</p>
                    <button onClick={() => setSelectedNewsSlug(n.slug)}>Читать полную версию статьи →</button>
                  </fieldset>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 4. SCHEDULE PAGE VIEW */}
        {currentPage === "schedule" && (
          <div>
            <h3>Расписание групповых спортивных занятий</h3>
            <p>Воспользуйтесь фильтрами для быстрого подбора удобного тренировочного цикла:</p>
            
            <fieldset style={{ marginBottom: "16px" }}>
              <legend><strong>Панель фильтров</strong></legend>
              <table border={0} cellPadding={4}>
                <tbody>
                  <tr>
                    <td>Поиск по названию/тренеру:</td>
                    <td>
                      <input
                        type="text"
                        placeholder="Например, Пилатес"
                        value={schedSearchQuery}
                        onChange={e => setSchedSearchQuery(e.target.value)}
                      />
                    </td>
                    <td>Выбрать зал:</td>
                    <td>
                      <select value={schedFilterHall} onChange={e => setSchedFilterHall(e.target.value)}>
                        <option value="">Все залы</option>
                        {gymHalls.map(h => (
                          <option key={h.id} value={h.id}>{h.name}</option>
                        ))}
                      </select>
                    </td>
                  </tr>
                  <tr>
                    <td>Поиск по дате (ГГГГ-ММ-ДД):</td>
                    <td>
                      <input
                        type="text"
                        placeholder="2026-05"
                        value={schedFilterDate}
                        onChange={e => setSchedFilterDate(e.target.value)}
                      />
                    </td>
                    <td>Выбрать группу:</td>
                    <td>
                      <select value={schedFilterGroup} onChange={e => setSchedFilterGroup(e.target.value)}>
                        <option value="">Все группы</option>
                        {groups.map(g => (
                          <option key={g.id} value={g.id}>{g.name}</option>
                        ))}
                      </select>
                    </td>
                    <td>
                      <button onClick={() => {
                        setSchedSearchQuery("");
                        setSchedFilterHall("");
                        setSchedFilterDate("");
                        setSchedFilterGroup("");
                      }}>Сбросить все</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </fieldset>

            <table border={1} cellPadding={8} style={{ width: "100%", textAlign: "left" }}>
              <thead>
                <tr style={{ backgroundColor: "#f2f2f2" }}>
                  <th>Группа (Workout)</th>
                  <th>Инструктор</th>
                  <th>Аудитория/Зал</th>
                  <th>Время проведения</th>
                  <th>Стоимость курса</th>
                  <th>Действие</th>
                </tr>
              </thead>
              <tbody>
                {filteredSchedule.length === 0 ? (
                  <tr>
                    <td colSpan={6} align="center">Занятий с выбранными фильтрами не найдено</td>
                  </tr>
                ) : (
                  filteredSchedule.map(sc => {
                    const groupItem = groups.find(g => g.id === sc.groupId);
                    return (
                      <tr key={sc.id}>
                        <td>
                          <strong>{sc.groupName || `Группа-${sc.groupId}`}</strong>
                          <br />
                          <small>({sc.workoutTypeName || "Групповой тренинг"})</small>
                        </td>
                        <td>{sc.instructorNames?.join(", ") || "Инструктор"}</td>
                        <td>{sc.hallName || `Зал ${sc.hallId}`}</td>
                        <td>
                          {sc.startTime.substring(11, 16)} - {sc.endTime.substring(11, 16)} ({sc.startTime.substring(0, 10)})
                        </td>
                        <td>
                          <strong>{convertPrice(sc.pricePerCycle || 120)}</strong>
                        </td>
                        <td>
                          <button onClick={() => handleEnrollGroup(sc.groupId, 0)}>Записаться на весь цикл</button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* 5. INDIVIDUAL SESSIONS PAGE VIEW */}
        {currentPage === "individual-sessions" && (
          <div>
            <h3>Индивидуальные занятия с персональным тренером</h3>
            <p>
              Персональный тренинг гарантирует максимальный результат. Заполните форму заказа тренировки ниже.
            </p>

            <fieldset style={{ marginBottom: "16px" }}>
              <legend><strong>🏷️ Забронировать индивидуальное занятие</strong></legend>
              <form onSubmit={handleBookIndividual}>
                <p>
                  Выберите вашего персонального инструктора:{" "}
                  <select
                    required
                    value={bookingInstructorId}
                    onChange={e => setBookingInstructorId(e.target.value)}
                  >
                    <option value="">-- Выберите тренера --</option>
                    {instructors.map(inst => (
                      <option key={inst.id} value={inst.id}>
                        {getUserName(inst.userId)} ({inst.experienceYears} лет стаж)
                      </option>
                    ))}
                  </select>
                </p>
                <p>
                  Направление персональной тренировки:{" "}
                  <select
                    required
                    value={bookingWorkoutTypeId}
                    onChange={e => setBookingWorkoutTypeId(e.target.value)}
                  >
                    <option value="">-- Направление --</option>
                    {workoutTypes.filter(w => w.category === "individual").map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} — ({convertPrice(w.pricePerSession)}/час)
                      </option>
                    ))}
                  </select>
                </p>
                <p>
                  Желательное Дата и Время:{" "}
                  <input
                    type="datetime-local"
                    required
                    value={bookingDatetime}
                    onChange={e => setBookingDatetime(e.target.value)}
                  />
                </p>
                <p>
                  Продолжительность занятия (мин):{" "}
                  <input
                    type="number"
                    min={30}
                    max={180}
                    step={15}
                    required
                    value={bookingDuration}
                    onChange={e => setBookingDuration(parseInt(e.target.value))}
                  />
                </p>
                <p>
                  Применить промокод (необязательно):{" "}
                  <input
                    type="text"
                    value={bookingPromoCode}
                    onChange={e => setBookingPromoCode(e.target.value)}
                    placeholder="Например, GOBESTIND"
                  />{" "}
                  <button type="button" onClick={handleValidatePromo}>Проверить промокод</button>
                </p>

                {bookingMessage && <p style={{ color: "green" }}>{bookingMessage}</p>}
                {bookingError && <p style={{ color: "red" }}>{bookingError}</p>}

                <p>
                  <button type="submit"><strong>Зарегистрировать Персональную Тренировку</strong></button>
                </p>
              </form>
            </fieldset>

            {currentUser && (
              <div>
                <h4>Зарегистрированные персональные тренировки в Форсаже</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", textAlign: "left" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Направление</th>
                      <th>{currentUser.role === "client" ? "Инструктор" : "Клиент"}</th>
                      <th>Дата / Время</th>
                      <th>Длительность</th>
                      <th>Статус оплаты и проведения</th>
                      <th>Действие по отмене</th>
                    </tr>
                  </thead>
                  <tbody>
                    {individualSessions.length === 0 ? (
                      <tr>
                        <td colSpan={6} align="center">Список индивидуальных занятий пока пуст. Забронируйте первую тренировку выше!</td>
                      </tr>
                    ) : (
                      individualSessions.map(sess => (
                        <tr key={sess.id}>
                          <td><strong>{sess.workoutTypeName || `Тренировка #${sess.workoutTypeId}`}</strong></td>
                          <td>
                            {currentUser.role === "client"
                              ? sess.instructorName || `Тренер #${sess.instructorId}`
                              : sess.clientName || `Клиент #${sess.clientId}`}
                          </td>
                          <td>{sess.datetime.replace("T", " ")}</td>
                          <td>{sess.durationMinutes} минут</td>
                          <td>
                            {sess.status === "scheduled" && <span style={{ color: "blue" }}>Запланирована (Ожидает проведения)</span>}
                            {sess.status === "completed" && <span style={{ color: "green" }}>Успешно завершена (Проведена)</span>}
                            {sess.status === "cancelled" && <span style={{ color: "red" }}>Отменена</span>}
                          </td>
                          <td>
                            {sess.status === "scheduled" && (
                              <div>
                                {currentUser.role === "instructor" ? (
                                  <button onClick={() => handleCompleteSession(sess.id)}>Отметить "Проведено"</button>
                                ) : (
                                  <button onClick={() => handleCancelSession(sess.id)}>Отменить тренировку</button>
                                )}
                              </div>
                            )}
                            {sess.status !== "scheduled" && <span>нет действий</span>}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* 6. PROMOCODES PAGE VIEW */}
        {currentPage === "promocodes" && (
          <div>
            <h3>Активные промокоды спортивного сезона</h3>
            <p>Используйте данные промокоды при бронировании индивидуальных занятий для получения скидки:</p>
            <table border={1} cellPadding={8} style={{ width: "100%", textAlign: "left" }}>
              <thead>
                <tr style={{ backgroundColor: "#f2f2f2" }}>
                  <th>Буквенный Код</th>
                  <th>Размер скидки (%)</th>
                  <th>Сфера действия промокода</th>
                  <th>Действителен с</th>
                  <th>Действителен по</th>
                </tr>
              </thead>
              <tbody>
                {activePromoCodes.map(promo => (
                  <tr key={promo.id}>
                    <td><code>{promo.code}</code></td>
                    <td><strong>{promo.discountPercent}%</strong></td>
                    <td>
                      {promo.applicableTo === "all" && "Ко всем типам услуг"}
                      {promo.applicableTo === "individual" && "Регистрация персональных занятий"}
                      {promo.applicableTo === "group" && "Групповые спортивные программы"}
                      {promo.applicableTo === "club_card" && "Оформление Клубной Карты"}
                    </td>
                    <td>{promo.validFrom}</td>
                    <td>{promo.validTo}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 7. VACANCIES PAGE VIEW */}
        {currentPage === "vacancies" && (
          <div>
            <h3>Вакансии фитнес-клуба</h3>
            <p>Хотите стать частью нашей дружной профессиональной команды? Мы ищем амбициозных специалистов:</p>
            {vacancies.filter(v => v.isActive).map(v => (
              <fieldset key={v.id} style={{ marginBottom: "16px" }}>
                <legend><strong>{v.position}</strong></legend>
                <p><strong>Описание обязанностей и требований:</strong></p>
                <p>{v.description}</p>
                {v.salary && <p>Предлагаемая оплата труда: <strong>{v.salary}</strong></p>}
                <p><small>Ждем ваши резюме по адресу: <code>hr@fitness.by</code></small></p>
              </fieldset>
            ))}
          </div>
        )}

        {/* 8. REVIEWS PAGE VIEW */}
        {currentPage === "reviews" && (
          <div>
            <h3>Отзывы наших клиентов</h3>
            <p>Реальные мнения посетителей, тренирующихся в фитнес-клубе «ФОРСАЖ»:</p>
            {reviews.map(rev => (
              <fieldset key={rev.id} style={{ marginBottom: "12px" }}>
                <legend><strong>{rev.clientName || "Почетный клиент"}</strong></legend>
                <div>Оценка: {Array(rev.rating).fill("★").join("")}{Array(5 - rev.rating).fill("☆").join("")} ({rev.rating} из 5)</div>
                <p><em>"{rev.text}"</em></p>
                <div style={{ textAlign: "right" }}>
                  <small>Дата публикации: {rev.createdAt.substring(0, 10)} {rev.createdAt.substring(11, 16)}</small>
                </div>
              </fieldset>
            ))}

            <hr />

            {currentUser && currentClient ? (
              <fieldset>
                <legend><strong>✍️ Написать собственный отзыв о работе клуба</strong></legend>
                <form onSubmit={handleAddReview}>
                  <p>
                    Оценка клубу (от 1 до 5 звезд):{" "}
                    <select value={newReviewRating} onChange={e => setNewReviewRating(parseInt(e.target.value))}>
                      <option value="5">5 звезд — Отлично, рекомендую!</option>
                      <option value="4">4 звезды — Хороший сервис и тренажеры</option>
                      <option value="3">3 звезды — Есть некоторые замечания</option>
                      <option value="2">2 звезды — Плохое обслуживание</option>
                      <option value="1">1 звезда — Ужасно, не приду больше</option>
                    </select>
                  </p>
                  <p>
                    Текст вашего отзыва:
                    <br />
                    <textarea
                      rows={4}
                      style={{ width: "100%" }}
                      required
                      placeholder="Расскажите о ваших результатах тренировок, чистоте в залах и работе тренеров..."
                      value={newReviewText}
                      onChange={e => setNewReviewText(e.target.value)}
                    />
                  </p>
                  {reviewSubmitMessage && <p><strong>{reviewSubmitMessage}</strong></p>}
                  <p>
                    <button type="submit">Опубликовать мой отзыв в системе</button>
                  </p>
                </form>
              </fieldset>
            ) : (
              <p>
                <em>* Только авторизованные постоянные Члены Клуба могут публиковать отзывы о тренировках.</em>
              </p>
            )}
          </div>
        )}

        {/* 9. FAQ PAGE VIEW */}
        {currentPage === "faq" && (
          <div>
            <h3>Популярные вопросы и ответы (FAQ)</h3>
            <p>Вы можете развернуть или сложить каждый вопрос, нажав на него:</p>
            {faqs.map(faq => (
              <details key={faq.id} style={{ marginBottom: "10px", padding: "8px", border: "1px solid #ddd" }}>
                <summary style={{ cursor: "pointer", fontWeight: "bold" }}>
                  ❓ {faq.question}
                </summary>
                <p style={{ marginTop: "8px", paddingLeft: "15px" }}>
                  {faq.answer}
                </p>
                <small style={{ color: "#777" }}>Добавлен на сайт: {faq.addedDate}</small>
              </details>
            ))}
          </div>
        )}

        {/* 10. CONTACTS PAGE VIEW */}
        {currentPage === "contacts" && (
          <div>
            <h3>Контактная информация фитнес-центра «ФОРСАЖ»</h3>
            
            <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
              <tbody>
                <tr>
                  <td>📍 <strong>Адрес комплекса:</strong></td>
                  <td>Республика Беларусь, г. Минск, пр. Независимости, д. 99, спортивный корпус «Форсаж»</td>
                </tr>
                <tr>
                  <td>📞 <strong>Телефоны отдела рецепции:</strong></td>
                  <td>+375 (17) 200-30-40, +375 (29) 111-22-33 (ежедневно с 7:00 до 23:00)</td>
                </tr>
                <tr>
                  <td>✉️ <strong>Электронная почта поддержки:</strong></td>
                  <td><code>support@fitness.by</code>, <code>info@fitness.by</code></td>
                </tr>
              </tbody>
            </table>

            <h3>Наш управленческий и административный состав</h3>
            {contacts.map(c => (
              <fieldset key={c.id} style={{ marginBottom: "12px" }}>
                <legend><strong>{c.fullName}</strong></legend>
                <table border={0} cellPadding={4}>
                  <tbody>
                    <tr>
                      <td valign="top">
                        {c.imageUrl && (
                          <img
                            src={c.imageUrl}
                            alt={c.fullName}
                            width="90"
                            style={{ border: "1px dashed #555" }}
                            referrerPolicy="no-referrer"
                          />
                        )}
                      </td>
                      <td valign="top" style={{ paddingLeft: "15px" }}>
                        <p>Должность: <strong>{c.role}</strong></p>
                        <p>Контактный телефон: {c.phone}</p>
                        <p>Email: <code>{c.email}</code></p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </fieldset>
            ))}
          </div>
        )}

        {/* 11. PROFILE PAGE VIEW */}
        {currentPage === "profile" && currentUser && (
          <div>
            <h3>Личный кабинет Члена Клуба</h3>
            <fieldset style={{ marginBottom: "16px" }}>
              <legend><strong>Данные вашей учетной записи</strong></legend>
              <p>Логин: <strong>{currentUser.username}</strong></p>
              <p>ФИО: <strong>{currentUser.fullName}</strong></p>
              <p>Почта: {currentUser.email}</p>
              <p>Категория доступа: <u>{currentUser.role.toUpperCase()}</u></p>
              
              {currentClient && (
                <div>
                  <p>Дата рождения: {currentClient.dateOfBirth}</p>
                  <p>Номер телефона: {currentClient.phone}</p>
                  <p>Адрес проживания: {currentClient.address}</p>
                  <p>Дата открытия карты: {currentClient.registrationDate}</p>
                  <p>
                    Статус абонемента:{" "}
                    <strong>
                      {currentClient.clubCardId
                        ? `АКТИВЕН (Карта #${currentClient.clubCardId})`
                        : "ОТСУТСТВУЕТ (Пожалуйста, выберите и активируйте клубную карту ниже!)"}
                    </strong>
                  </p>
                </div>
              )}
            </fieldset>

            {currentClient && (
              <fieldset>
                <legend><strong>💳 Оформить или обновить Клубную Карту</strong></legend>
                <p>
                  Выберите и оплатите наиболее подходящий вариант карты для проведения тренировок:
                </p>
                
                <table border={1} cellPadding={8} style={{ width: "100%", textAlign: "center" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Тариф Клубной Карты</th>
                      <th>Стоимость тарифа</th>
                      <th>Срок действия карты</th>
                      <th>Кнопка заказа</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong>Пробная карта (Trial)</strong></td>
                      <td>{convertPrice(15)}</td>
                      <td>1 день</td>
                      <td>
                        <button onClick={() => handlePurchaseCard("trial", 15)}>Активировать пробную карту</button>
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Месячный абонемент (Monthly)</strong></td>
                      <td>{convertPrice(100)}</td>
                      <td>30 дней</td>
                      <td>
                        <button onClick={() => handlePurchaseCard("monthly", 100)}>Купить на 30 дней</button>
                      </td>
                    </tr>
                    <tr>
                      <td><strong>Годовой абонемент (Yearly)</strong></td>
                      <td>{convertPrice(850)}</td>
                      <td>365 дней</td>
                      <td>
                        <button onClick={() => handlePurchaseCard("yearly", 850)}>Купить на 365 дней (Выгодно)</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </fieldset>
            )}
          </div>
        )}

        {/* 12. ADMIN STATISTICS PAGE VIEW */}
        {currentPage === "statistics" && currentUser?.role === "admin" && (
          <div>
            <h3>Панель Аналитики (Администратор)</h3>
            <p>Данный раздел доступен исключительно суперпользователям для контроля финансовых и демографических данных.</p>

            {/* Bulk increase controls */}
            <fieldset style={{ marginBottom: "16px" }}>
              <legend><strong>Изменение цен в масштабе всего клуба</strong></legend>
              <form onSubmit={handleBulkPriceIncrease}>
                <p>
                  Выберите тип тренировки для наценки:{" "}
                  <select required value={bulkPriceId} onChange={e => setBulkPriceId(e.target.value)}>
                    <option value="">-- Выбрать услугу --</option>
                    {workoutTypes.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} (текущая цена: {convertPrice(w.pricePerSession || w.pricePerCycle || 0)})
                      </option>
                    ))}
                  </select>
                </p>
                <p>
                  Процент повышения стоимости (%):{" "}
                  <input
                    type="number"
                    min={1}
                    max={100}
                    required
                    value={bulkPricePercent}
                    onChange={e => setBulkPricePercent(parseInt(e.target.value))}
                  />
                </p>
                {bulkMessage && <p><strong>ℹ️ {bulkMessage}</strong></p>}
                <p>
                  <button type="submit"><strong>Повысить цены на выбранную услугу</strong></button>
                </p>
              </form>
            </fieldset>

            {statistics ? (
              <div>
                <h4>Общая посещаемость по спортивным группам</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Название учебной группы</th>
                      <th>Количество регулярных классов</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statistics.classesCountByGroup.map((item, idx) => (
                      <tr key={idx}>
                        <td>{item.groupName}</td>
                        <td><strong>{item.count} занятий</strong></td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <h4>Средние демографические показатели Членов Клуба</h4>
                <ul>
                  <li>Средний возраст тренирующихся: <strong>{statistics.ageStats.average} лет</strong></li>
                  <li>Медианный возраст тренирующихся: <strong>{statistics.ageStats.median} лет</strong></li>
                </ul>

                <h4>Популярность направлений (Уникальных клиентов записано)</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Наименование спорт направления</th>
                      <th>Количество уникальных клиентов</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statistics.popularityByWorkoutType.map((item, idx) => (
                      <tr key={idx}>
                        <td>{item.workoutName}</td>
                        <td><strong>{item.uniqueClientsCount} чел.</strong></td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <h4>Выручка по спортивным направлениям</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Направление</th>
                      <th>Суммарная выручка</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statistics.profitabilityByWorkoutType.map((item, idx) => (
                      <tr key={idx}>
                        <td>{item.workoutName}</td>
                        <td><strong>{convertPrice(item.revenue)}</strong></td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <h4>Детальный финансовый отчет по каждому Члену Клуба</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Участник</th>
                      <th>Телефон</th>
                      <th>Сумма за группы</th>
                      <th>Сумма за инд. занятия</th>
                      <th>Сумма за абонементы</th>
                      <th>Общий платеж (Всего принес)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statistics.clientPayments.map((item, idx) => (
                      <tr key={idx}>
                        <td><strong>{item.fullName}</strong></td>
                        <td>{item.phone}</td>
                        <td>{convertPrice(item.workoutSum)}</td>
                        <td>{convertPrice(item.individualSum)}</td>
                        <td>{convertPrice(item.cardsSum)}</td>
                        <td style={{ backgroundColor: "#e2ffe2" }}><strong>{convertPrice(item.totalPaid)}</strong></td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <h4>Ежемесячно учтенная кассовая выручка спорткомплекса</h4>
                <table border={1} cellPadding={8} style={{ width: "100%", marginBottom: "16px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f2f2f2" }}>
                      <th>Отчетный Месяц</th>
                      <th>Суммарная кассовая выручка</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statistics.monthlyRevenue.map((item, idx) => (
                      <tr key={idx}>
                        <td>{item.month}</td>
                        <td><strong>{convertPrice(item.revenue)}</strong></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p>Загрузка статистики...</p>
            )}
          </div>
        )}
      </div>

      {/* FOOTER BAR */}
      <hr />
      <div style={{ textAlign: "center", padding: "12px 0", color: "#666" }}>
        <p>© 2026 Фитнес-клуб «ФОРСАЖ». Все права защищены. Разработано на чистом HTML без использования сторонних CSS библиотек / Bootstrap.</p>
      </div>
    </div>
  );
}
