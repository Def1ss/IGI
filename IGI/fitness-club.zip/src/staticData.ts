// Static arrays of standard fitness database for client side compile support
import { User, InstructorProfile } from "./types";

export interface Equipment {
  id: number;
  name: string;
  type: string;
  lastMaintenanceDate: string;
}

export interface GymHall {
  id: number;
  name: string;
  capacity: number;
  equipments: { equipmentId: number; quantity: number }[];
}

export const users: User[] = [
  { id: 1, username: "admin", email: "admin@fitness.by", role: "admin", fullName: "Иван Иванов" },
  { id: 2, username: "trainer_pavel", email: "pavel@fitness.by", role: "instructor", fullName: "Павел Сидоров" },
  { id: 3, username: "trainer_olga", email: "olga@fitness.by", role: "instructor", fullName: "Ольга Козлова" },
  { id: 4, username: "trainer_dmitry", email: "dmitry@fitness.by", role: "instructor", fullName: "Дмитрий Новиков" },
  { id: 5, username: "trainer_elena", email: "elena@fitness.by", role: "instructor", fullName: "Елена Смирнова" },
  { id: 6, username: "trainer_artur", email: "artur@fitness.by", role: "instructor", fullName: "Артур Петров" },
  { id: 7, username: "alex123", email: "alex@mail.ru", role: "client", fullName: "Александр Петров" },
  { id: 8, username: "mary_k", email: "mary@yandex.ru", role: "client", fullName: "Мария Ковалева" },
  { id: 9, username: "den_by", email: "denis@tut.by", role: "client", fullName: "Денис Кравченко" },
  { id: 10, username: "kate_m", email: "kate@gmail.com", role: "client", fullName: "Екатерина Морозова" },
  { id: 11, username: "serg_f", email: "sergei@fitness.by", role: "client", fullName: "Сергей Федоров" },
  { id: 12, username: "vlad_gym", email: "vlad@mail.ru", role: "client", fullName: "Владислав Тарасов" },
  { id: 13, username: "anna_s", email: "anna@yandex.by", role: "client", fullName: "Анна Соколова" },
  { id: 14, username: "maxim_p", email: "maxim@tut.by", role: "client", fullName: "Максим Попов" },
  { id: 15, username: "julia_r", email: "julia@gmail.com", role: "client", fullName: "Юлия Рыбакова" },
  { id: 16, username: "artem_k", email: "artem@mail.ru", role: "client", fullName: "Артем Кузнецов" }
];

export const instructors: InstructorProfile[] = [
  { id: 1, userId: 2, specializationIds: [1, 2, 6], experienceYears: 8, photoUrl: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&q=80&w=200", hireDate: "2020-03-15" },
  { id: 2, userId: 3, specializationIds: [3, 4, 6], experienceYears: 5, photoUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200", hireDate: "2021-08-10" },
  { id: 3, userId: 4, specializationIds: [1, 5, 6], experienceYears: 12, photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200", hireDate: "2018-02-01" },
  { id: 4, userId: 5, specializationIds: [3, 5], experienceYears: 6, photoUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200", hireDate: "2022-09-01" },
  { id: 5, userId: 6, specializationIds: [2, 4, 6], experienceYears: 4, photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200", hireDate: "2023-11-20" }
];

export const equipments: Equipment[] = [
  { id: 1, name: "Беговая дорожка LifeFitness", type: "cardio", lastMaintenanceDate: "2026-04-10" },
  { id: 2, name: "Велотренажер TechnoGym", type: "cardio", lastMaintenanceDate: "2026-04-12" },
  { id: 3, name: "Жим ногами регулируемый", type: "strength", lastMaintenanceDate: "2026-03-15" },
  { id: 4, name: "Машина Смита", type: "strength", lastMaintenanceDate: "2026-02-28" },
  { id: 5, name: "Набор TRX лент", type: "functional", lastMaintenanceDate: "2026-05-01" },
  { id: 6, name: "Гири чугунные (8-32 кг)", type: "functional", lastMaintenanceDate: "2026-05-05" }
];

export const gymHalls: GymHall[] = [
  { id: 1, name: "Кардио-зона и Силовой Зал 1", capacity: 30, equipments: [{ equipmentId: 1, quantity: 8 }, { equipmentId: 2, quantity: 5 }, { equipmentId: 3, quantity: 2 }, { equipmentId: 4, quantity: 2 }] },
  { id: 2, name: "Малый зал пилатеса и йоги", capacity: 15, equipments: [{ equipmentId: 5, quantity: 10 }] },
  { id: 3, name: "Зал функционального тренинга", capacity: 20, equipments: [{ equipmentId: 5, quantity: 15 }, { equipmentId: 6, quantity: 12 }] }
];
